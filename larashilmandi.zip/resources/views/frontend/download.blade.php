@extends('frontend.components.layouts')
@section('content')
    
@endsection