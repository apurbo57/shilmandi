<html class="no-js" lang="en"><head><style>
    #errorHandling img{
        width: 30%;
    }
    @media  screen and (max-width:767px) {
      #errorHandling img{
            width: 60%;
      }
    }
</style>




<script async="" src="https://www.googletagmanager.com/gtag/js?id=UA-131571982-2" type="64c389be0a9e467db0b8a158-text/javascript"></script>
<script type="64c389be0a9e467db0b8a158-text/javascript">
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());

      gtag('config', 'UA-131571982-2');
    </script>





<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="PencilBox Training Institute provide training in IT sector. Their Our mission is to provide international standard training in Bangladesh's IT sector.">
<meta name="keywords" content="Pencilbox, Training, Institute, IT, Bangladesh Training, Web Development, Graphics Design, International Training, Pencilbox Training Institute, ASP.Net, PHP, Laravel, Full-Free Women Course">
<meta name="csrf-token" content="WnBTXqfBknwUdyfPsE6dOXjiDSDyHnrXCkKJhBeR">
<title>    404 Not Fund
</title>
<link rel="manifest" href="site.webmanifest">
<link rel="shortcut icon" type="image/x-icon" href="../images/pencilbox-06b.png">



<link rel="stylesheet" href="../css/bootstrap.min.css">

<link rel="stylesheet" href="../css/owl.carousel.min.css">

<link rel="stylesheet" type="text/css" href="../css/slick.css">

<link rel="stylesheet" href="../css/animate.min.css" type="text/css">

<link rel="stylesheet" href="../css/magnific-popup.min.css" type="text/css">

<link rel="stylesheet" href="../css/fontawesome-all.min.css" type="text/css">

<link rel="stylesheet" href="../css/meanmenu.min.css" type="text/css">
<link href="../css/datepicker.min.css" rel="stylesheet" type="text/css">

<link rel="stylesheet" href="../css/style2.min_4.css" type="text/css">

<link rel="stylesheet" href="../css/responsive.min_4.css" type="text/css">
<link href="../css/select2.min.css" rel="stylesheet" type="text/css">
<script src="api.js" type="64c389be0a9e467db0b8a158-text/javascript"></script>
<style>
        input[type='number'] {
            -moz-appearance:textfield;
        }
        
        input::-webkit-outer-spin-button,
        input::-webkit-inner-spin-button {
            -webkit-appearance: none;
        }
    </style>
<style>
        #mobile-menu ul li{
            position:relative;
        }
        #mobile-menu ul li a::before {
            content: "";
            position: absolute;
            bottom: 10px;
            width: 0;
            height: 2px;
            background-color: #FBB243;
            transition: width .3s ease-in-out;
        }
        #mobile-menu ul li a:hover::before{
            width: calc(100% - 20px);
            transition: width .3s ease-in-out;
        }
    </style>

<script src="api.js" async="" defer="" type="64c389be0a9e467db0b8a158-text/javascript"></script>
<script type="64c389be0a9e467db0b8a158-text/javascript">
       function onSubmit(token) {
         document.getElementByClass("basic-form2").submit();
         document.getElementsByClassName("basic-form2-seip").submit();
       }

       function validate(event) {
          event.preventDefault();
        grecaptcha.execute();
    }

    function onload() {
      var element = document.getElementById('submit');
      var submit_form = document.getElementById('submit_form');
      var submit_form_class = document.getElementById('submit_form_class');
      var submit_form_pencilbox = document.getElementById('pencilbox-button');
      element.onclick = validate;
      submit_form.onclick = validate;
      submit_form_class.onclick = validate;
      submit_form_pencilbox.onclick = validate;
    }
     </script>

<script type="64c389be0a9e467db0b8a158-text/javascript">
            !function(f,b,e,v,n,t,s)
            {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
            n.callMethod.apply(n,arguments):n.queue.push(arguments)};
            if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
            n.queue=[];t=b.createElement(e);t.async=!0;
            t.src=v;s=b.getElementsByTagName(e)[0];
            s.parentNode.insertBefore(t,s)}(window, document,'script',
            'https://connect.facebook.net/en_US/fbevents.js');
            fbq('init', '1000677934197071');
            fbq('track', 'PageView');
        </script>
<noscript><img height="1" width="1" style="display:none"
        src="https://www.facebook.com/tr?id=1000677934197071&ev=PageView&noscript=1"
        /></noscript>

</head>
<body>


<div id="preloader-active">
<div class="preloader d-flex align-items-center justify-content-center">
<div class="preloader-inner position-relative">
<div class="preloader-circle"></div>
<div class="preloader-img pere-text">
<img src="../images/pencilbox-06b.png" alt="" loading="lazy">
</div>
</div>
</div>
</div>













<style>
    @font-face {
        font-family: 'pencilboxModalFont';
        src: url('../fonts/Montserrat-Bold.ttf')  format('truetype');
    }

    .pencilbox-modal {
        width: 405px !important;
        overflow: visible !important;
    }

    .pencilbox-modal-logo {
        width: 45%;
        margin: 5px auto 10px 100px !important;
    }

    .pencilbox-modal-title {
        text-align: center;
        font-family: Montserrat;
        font-style: normal;
        margin-bottom: 18px;
        font-weight: bold;
        font-size: 23px;
        color: rgba(65,66,69,1) !important;
    }

    .pencilbox-modal-text-under-title {
        color: #6C6D70 !important;
        font-family: Montserrat;
        font-weight: 600;
        text-align: center;
    }

    .counter-form {
        /*width: 333px !important;*/
        height: 45px !important;
        border-radius: 4px !important;
        font-family: Montserrat;
        font-weight: bold !important;
        font-size: 15px !important;
        border: 2px solid rgb(191 191 191) !important;
        /*color: rgba(209,211,212,1) !important;*/
    }

    .counter-form::-webkit-input-placeholder {
        color: rgba(209,211,212,1) !important;
        font-family: Montserrat !important;
        /*font-weight: bold !important;*/
        font-size: 15px !important;
        /*font-style: normal !important;*/
    }

    .line {
        position: relative;
        overflow: hidden;
        font-family: Montserrat;
        font-weight: bold !important;
        font-size: 15px !important;
        color: rgba(98,101,107,1) !important;
    }

    .line:before, .line:after {
        content: " ";
        position: absolute;
        top: 50%;
        margin-left: -999em;
        width: 998em;
        border-top: 1px solid #B5B6B9;
    }

    .line:after {
        left: auto;
        width: 999em;
        margin: 0 0 0 1em;
    }

    .pencilbox-button {
        border: 0 !important;
        /*width: 332px !important;*/
        height: 45px !important;
        background: rgb(248, 158, 0) !important;
        border-radius: 4px !important;
        font-family: Montserrat;
        font-weight: bold !important;
        font-size: 17px !important;
        color: rgba(255,255,255,1) !important;
    }

    .pencilbox-modal-footer-devider {
        width: 100%;
        display: block;
        height: 2px;
        background-color: #A8A9AD
    }

    .pencilbox-modal-footer-link {
        font-family: Montserrat;
        font-weight: 600;
        font-size: 13px !important;
        color: rgba(248,158,0,1) !important;
    }

    .pencilbox-modal-footer-text {
        font-family: Montserrat;
        font-weight: 600;
        font-size: 13px !important;
        color: rgba(79,82,88,1) !important;
        margin-top: 16px !important;
        margin-bottom: -16px !important;
    }

    @media (max-width: 414px) {
        .pencilbox-modal {
            width: 385px !important;
            overflow: visible !important;
            top: -40px;
        }

        .counter-form {
            /*width: 315px !important;*/
            height: 45px !important;
            border-radius: 4px !important;
            font-family: Montserrat;
            font-weight: bold !important;
            font-size: 15px !important;
            /*color: rgba(209,211,212,1) !important;*/
        }

        .pencilbox-button {
            border: 0 !important;
            /*width: 315px !important;*/
            height: 45px !important;
            background: #F7B019 !important;
            border-radius: 4px !important;
            font-family: Montserrat;
            font-weight: bold !important;
            font-size: 17px !important;
            color: rgba(255,255,255,1) !important;
        }
    }

    @media (max-width: 375px) {
        .pencilbox-modal {
            width: 345px !important;
            overflow: visible !important;
            top: -40px;
        }

        .counter-form {
            /*width: 280px !important;*/
            height: 45px !important;
            border-radius: 4px !important;
            font-family: Montserrat;
            font-weight: bold !important;
            font-size: 15px !important;
            /*color: rgba(209,211,212,1) !important;*/
        }

        .pencilbox-button {
            border: 0 !important;
            /*width: 280px !important;*/
            height: 45px !important;
            background: #F7B019 !important;
            border-radius: 4px !important;
            font-family: Montserrat;
            font-weight: bold !important;
            font-size: 17px !important;
            color: rgba(255,255,255,1) !important;
        }
    }

    @media (max-width: 320px) {
        .pencilbox-modal {
            width: 303px !important;
            overflow: visible !important;
            top: -40px;
        }

        .counter-form {
            /*width: 240px !important;*/
            height: 45px !important;
            border-radius: 4px !important;
            font-family: Montserrat;
            font-weight: bold !important;
            font-size: 15px !important;
            /*color: rgba(209,211,212,1) !important;*/
        }

        .pencilbox-button {
            border: 0 !important;
            /*width: 240px !important;*/
            height: 45px !important;
            background: #F7B019 !important;
            border-radius: 4px !important;
            font-family: Montserrat;
            font-weight: bold !important;
            font-size: 17px !important;
            color: rgba(255,255,255,1) !important;
        }
    }

</style>
<div class="header-top-are">
<div class="container">
<div class="row">
<div class="col-xl-7 col-lg-7 col-md-6 col-sm-6 col-6 ">
<div class="top-header-left wow fadeInUp">
<ul>
<li><i class="fa fa-hourglass-half"></i>
<span>9:00am - 6:00pm</span>
</li>
<li><a href="tel:+88- 01714 121 719"><i class="fa fa-phone"></i></a>
<strong><a href="tel:+880 1714 121719"> +880 1714 121719</a> <a href="tel:+880241010090" class="mob-number-view">/ +880241010090</a></strong>
</li>
<li><a href="/cdn-cgi/l/email-protection#137a7d757c5363767d707a7f717c6b3d7677663d7177"><i class="fa fa-envelope"></i></a> <span></span><strong><a href="/cdn-cgi/l/email-protection#1c75727a735c6c79727f75707e736432797869327e78"><span class="__cf_email__" data-cfemail="f891969e97b8889d969b91949a9780d69d9c8dd69a9c">[email&nbsp;protected]</span></a></strong>
</li>
</ul>
</div>
</div>
<div class="col-xl-3 col-lg-3 col-md-3 d-flex justify-content-center text-right mobile-social1">
<div class="header-social wow fadeInDown">
<ul>
<li><a href="https://www.facebook.com/PencilBoxTraining" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
<li><a href="https://www.instagram.com/pencilboxtraining" target="_blank"><i class="fab fa-instagram"></i></a></li>
<li><a href="https://www.linkedin.com/company/pencilboxtraining" target="_blank"><i class="fab fa-linkedin-in"></i></a></li>
<li><a href="https://www.youtube.com/channel/UCC6nCMUuzYlpJQNd87euwmw" target="_blank"><i class="fab fa-youtube"></i></a></li>
</ul>
</div>
</div>
<div class="col-xl-2 col-lg-2 col-md-3 col-sm-6 col-6 d-flex justify-content-end text-right">
<div class="header-social wow fadeInDown">
<ul>
<li>
<div class="text-center">
<a href="https://www.pencilbox.edu.bd/student/login" class=" btn-rounded mb-4"><i class="fa fa-sign-in-alt"></i><span>Login</span></a>
</div>
<div class="modal fade" id="modalLoginForm" tabindex="1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="padding-right: 0 !important;" data-backdrop="static" data-keyboard="false">
<div class="modal-dialog modal-dialog-centered pencilbox-modal" role="document">
<div class="modal-content" style="padding: 19px;">
<div class="modal-header" style="padding: 0 !important;">
<img class="pencilbox-modal-logo" src="../images/pencilbox_modal_logo.png" alt="logo" loading="lazy">
<button type="button" class="close modal-btn-bg" data-dismiss="modal" aria-label="Close" onclick="if (!window.__cfRLUnblockHandlers) return false; document.getElementById('zIndexId').classList.remove('zIndexClass')" data-cf-modified-64c389be0a9e467db0b8a158-=""><span aria-hidden="true">�</span></button>
</div>
<div class="modal-body" style="margin-top: -15px;">
<div class="pencilbox-modal-title">
Login
</div>
<form action="https://www.pencilbox.edu.bd/register/student-login" method="post">
<input type="hidden" name="_token" value="WnBTXqfBknwUdyfPsE6dOXjiDSDyHnrXCkKJhBeR"> <div class="row">
<div class="col-xl-12">
<div class="form-group">
<label></label>
<input class="form-control counter-form" type="name" placeholder="Email / Username" name="email_address" style="padding: 6px 10px;">
</div>
</div>
<div class="col-xl-12">
<div class="form-group">
<label></label>
<input class="form-control counter-form" type="password" placeholder="Password" name="password" style="padding: 6px 10px;">
</div>
</div>
<div class="col-xl-12">
<button class="register-btn apply-btn1 btn-block pencilbox-button" type="submit">
Continue
</button>
</div>
<div class="col-xl-12 mt-3">
<label for="remember_me">
<input checked="" id="remember_me" type="checkbox">
Remember Me</label>
<a href="" style="font-style: italic !important;
    font-weight: 500 !important;" class="pencilbox-modal-footer-link" data-toggle="modal" data-target="#modalForgetForm" onclick="if (!window.__cfRLUnblockHandlers) return false; document.getElementById('zIndexId').classList.remove('zIndexClass')" data-dismiss="modal" data-cf-modified-64c389be0a9e467db0b8a158-="">Forget
Password</a>
</div>
<div class="col-xl-12 text-center mt-2 pencilbox-modal-footer-devider">
</div>
<div class="col-xl-12 text-center mt-2 pencilbox-modal-footer-text">
Not a member yet? <a href="" class="pencilbox-modal-footer-link" data-toggle="modal" data-target="#modalRegistationForm" onclick="if (!window.__cfRLUnblockHandlers) return false; document.getElementById('zIndexId').classList.remove('zIndexClass')" data-dismiss="modal" data-cf-modified-64c389be0a9e467db0b8a158-="">Register</a>
</div>
</div>
</form>
</div>
</div>
</div>
</div>
<div class="modal fade" id="modalForgetForm" tabindex="1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" data-backdrop="static" data-keyboard="false">
<div class="modal-dialog modal-dialog-centered pencilbox-modal" role="document">
<div class="modal-content" style="padding: 19px;">
<div class="modal-header" style="padding: 0 !important;">
<img class="pencilbox-modal-logo" src="../images/pencilbox_modal_logo.png" alt="logo" loading="lazy">
<button type="button" class="close modal-btn-bg" data-dismiss="modal" aria-label="Close" onclick="if (!window.__cfRLUnblockHandlers) return false; document.getElementById('zIndexId').classList.remove('zIndexClass')" data-cf-modified-64c389be0a9e467db0b8a158-=""><span aria-hidden="true">�</span></button>
</div>
<div class="modal-body" style="margin-top: -15px;">
<div class="pencilbox-modal-title">
Reset Password
</div>
<p class="pencilbox-modal-text-under-title mb-3">Please enter
your email address and we’ll
send you a link to reset your password </p>
<form action="https://www.pencilbox.edu.bd/register/student-forget-password" method="post">
<input type="hidden" name="_token" value="WnBTXqfBknwUdyfPsE6dOXjiDSDyHnrXCkKJhBeR"> <div class="row">
<div class="col-xl-12">
<div class="form-group" style="margin-bottom: 0px !important;">
<label></label>
<input class="form-control counter-form" type="email" required="" placeholder="Enter your Email" name="email_address">
</div>
</div>
<div class="col-xl-12">
<div class="form-group" style="margin-bottom: 2rem !important;">
<button class="register-btn apply-btn1 btn-block pencilbox-button" type="submit">Submit
</button>
</div>
</div>
<div class="pencilbox-modal-footer-devider"></div>
<div class="col-xl-12 text-center mt-2 pencilbox-modal-footer-text">
Back to <a data-dismiss="modal" aria-label="Close" onclick="if (!window.__cfRLUnblockHandlers) return false; document.getElementById('zIndexId').classList.remove('zIndexClass')" class="pencilbox-modal-footer-link" data-cf-modified-64c389be0a9e467db0b8a158-="">Login</a>
</div>
</div>
</form>
</div>
</div>
</div>
</div>
<div class="modal fade" id="modalRegistationForm" tabindex="1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" data-backdrop="static" data-keyboard="false">
<div class="modal-dialog modal-dialog-centered pencilbox-modal" role="document">
<div class="modal-content" style="padding: 19px;">
<div class="modal-header" style="padding: 0 !important;">
<img class="pencilbox-modal-logo" src="../images/pencilbox_modal_logo.png" alt="logo" loading="lazy">
<button type="button" class="close modal-btn-bg" data-dismiss="modal" aria-label="Close" onclick="if (!window.__cfRLUnblockHandlers) return false; document.getElementById('zIndexId').classList.remove('zIndexClass')" data-cf-modified-64c389be0a9e467db0b8a158-=""><span aria-hidden="true">�</span></button>
</div>
<div class="modal-body" style="margin-top: -15px;">
<div class="pencilbox-modal-title">
Register
</div>







































<div id="afterRegistrationContinueFromCourseTop">
<form action="https://www.pencilbox.edu.bd/register/new" method="post" id="basic-form1">
<input type="hidden" name="_token" value="WnBTXqfBknwUdyfPsE6dOXjiDSDyHnrXCkKJhBeR"> <div class="row">
<div class="col-xl-12">
<div class="form-group">
<label></label>
<input class="form-control counter-form" type="email" placeholder="Email Address" name="email_address" id="email_address_registration_top" required="">
<span class="email_address_pre_registration_course_error text-danger" style="font-size: 13px !important;"></span>
</div>
</div>
<div class="col-xl-12">
<div class="form-group">
<label></label>
<input style="padding: 6px 10px;" class="form-control counter-form" type="text" placeholder="Username" id="username_registration_top" name="username" required="">
<span class="username_registration_course_error text-danger" style="font-size: 13px !important;"></span>
</div>
</div>
<div class="col-xl-12">
<div class="form-group">
<label></label>
<input style="padding: 6px 10px;" class="form-control counter-form" type="text" placeholder="Full Name" name="full_name" required="">
</div>
</div>
<div class="col-xl-12">
<div class="form-group">
<label></label>
<input style="padding: 6px 10px;" class="form-control counter-form" type="number" placeholder="Phone No" name="phone_number" required="">
</div>
</div>
<div class="col-xl-12">
<div class="form-group">
<label></label>
<input style="padding: 6px 10px;" class="form-control counter-form" type="password" placeholder="Enter your password" id="password_top" name="password" required="">
</div>
</div>
<div class="col-xl-12">
<div class="form-group">
<label></label>
<input style="padding: 6px 10px;" class="form-control counter-form" type="password" id="confirm_password_top" placeholder="Confirm password" name="confirm_password" required="">
<span class="password_registration_course_error text-danger" style="font-size: 13px !important;"></span>
</div>
</div>
<div class="col-xl-12" style="margin-top: -14px !important;">
<div class="form-group">
<button class="register-btn apply-btn1 btn-block pencilbox-button" id="registrationContinueBtnTop" type="submit">Continue
</button>
</div>
</div>
</div>
</form>
</div>
<div class="pencilbox-modal-text-under-title" style="color: #66656E !important; font-weight: 500; margin-bottom: 15px;
">
By joining I agree to the <a href="https://www.pencilbox.edu.bd/terms-and-condition" style="color: #227FD4; font-weight: 500">terms &amp;
conditions</a> of
PencilBox Training Institute
</div>
<div class="pencilbox-modal-footer-devider"></div>
<div class="col-xl-12 text-center mt-2 pencilbox-modal-footer-text" style="color: black">
Already a member? <a href="" class="pencilbox-modal-footer-link" data-toggle="modal" data-target="#modalLoginForm" onclick="if (!window.__cfRLUnblockHandlers) return false; document.getElementById('zIndexId').classList.remove('zIndexClass')" data-dismiss="modal" data-cf-modified-64c389be0a9e467db0b8a158-="">Login</a>
</div>
</div>
</div>
</div>
</div>
<div class="modal fade" id="modalDemoForm" tabindex="1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" data-backdrop="static" data-keyboard="false">
<div class="modal-dialog modal-dialog-centered pencilbox-modal" role="document">
<div class="modal-content" style="padding: 19px;">
<div class="modal-header" style="padding: 0 !important;">
<img class="pencilbox-modal-logo" src="../images/pencilbox_modal_logo.png" alt="logo" loading="lazy">
<button type="button" class="close modal-btn-bg" data-dismiss="modal" aria-label="Close" onclick="if (!window.__cfRLUnblockHandlers) return false; document.getElementById('zIndexId').classList.remove('zIndexClass')" data-cf-modified-64c389be0a9e467db0b8a158-=""><span aria-hidden="true">�</span></button>
</div>
<div class="modal-body">
<div class="pencilbox-modal-title">
Demo Design
</div>
<form action="https://www.pencilbox.edu.bd/register/student-forget-password" method="post">
<input type="hidden" name="_token" value="WnBTXqfBknwUdyfPsE6dOXjiDSDyHnrXCkKJhBeR"> <div class="row">
<div class="col-xl-12 ">
<div class="form-group">
<button class="register-btn apply-btn1 btn-block pencilbox-button" data-toggle="modal" data-target="#modalCheckMailForm" type="button">Check
your Email
</button>
<button class="register-btn apply-btn1 btn-block pencilbox-button" data-toggle="modal" data-target="#modalCongratulationWOLoginForm" type="button">
Congratulation without login
</button>
<button class="register-btn apply-btn1 btn-block pencilbox-button" data-toggle="modal" data-target="#modalCongratulationWLoginForm" type="button">
Congratulation with login
</button>
</div>
</div>
</div>
</form></div>
</div>
</div>
</div>
</li></ul></div>
<div class="modal fade" id="modalCheckMailForm" tabindex="1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" data-backdrop="static" data-keyboard="false">
<div class="modal-dialog modal-dialog-centered pencilbox-modal" role="document">
<div class="modal-content" style="padding: 19px;">
<div class="modal-header" style="padding: 0 !important;">
<img class="pencilbox-modal-logo" src="../images/pencilbox_modal_logo.png" alt="logo" loading="lazy">
<button type="button" class="close modal-btn-bg" data-dismiss="modal" aria-label="Close" onclick="if (!window.__cfRLUnblockHandlers) return false; document.getElementById('zIndexId').classList.remove('zIndexClass')" data-cf-modified-64c389be0a9e467db0b8a158-=""><span aria-hidden="true">�</span></button>
</div>
<div class="modal-body">
<div class="pencilbox-modal-title">
Check your Email
</div>
<p class="pencilbox-modal-text-under-title mb-3">Your Password
reset link has been successfully sent to your
email address!</p>
<div class="row">
<div class="pencilbox-modal-footer-devider"></div>
<div class="col-xl-12 text-center mt-2 pencilbox-modal-footer-text">
Back to <a href="" class="pencilbox-modal-footer-link" data-toggle="modal" data-target="#modalLoginForm" onclick="if (!window.__cfRLUnblockHandlers) return false; document.getElementById('zIndexId').classList.remove('zIndexClass')" data-dismiss="modal" data-cf-modified-64c389be0a9e467db0b8a158-="">Login</a>
</div>
</div>
</div>
</div>
</div>
</div>


</div>
</div>
</div>
</div>



<script data-cfasync="false" src="email-decode.min.js"></script><script type="64c389be0a9e467db0b8a158-text/javascript">

        function checkStudentEmail1(email) {
            var xmlHttp = new XMLHttpRequest();
            var server = 'https://pencilbox.edu.bd/student-email-check/' + email;
            xmlHttp.open('GET', server);
            xmlHttp.onreadystatechange = function () {
                if (xmlHttp.readyState == 4 && xmlHttp.status == 200) {
                    document.getElementById('emailRes1').innerHTML = xmlHttp.responseText;
                    if (xmlHttp.responseText == 'This email already exist. Try another email to register.') {
                        document.getElementById('regBtn1').disabled = true;
                    } else {
                        document.getElementById('regBtn1').disabled = false;
                    }
                }
            }
            xmlHttp.send();
        }

    </script>


<style>
    @font-face {
        font-family: 'seipFont';
        src: url('../fonts/typewriter-serial-extrabold-regular.ttf')  format('truetype');
    }
    .seip-pu {
        background-color: #1DB78D;
        padding: 0 3px 0 3px;
        color: #fff;
        font-weight: bold;
        margin-right: -3.5px;
        font-size: 17px;
        font-family: seipFont;
    }
    .seip-bl {
        background-color: #524FA1;
        padding: 0 3px 0 3px;
        color: #fff;
        font-weight: bold;
        margin-right: -3.5px;
        font-size: 17px;
        font-family: seipFont;
    }
</style>
<div id="zIndexId" class="header-area header-sticky">
<div class="container">
<div class="row">
<div class="col-xl-2 col-lg-2 col-md-2">
<div class="logo">
<a href="https://www.pencilbox.edu.bd"><img src="../images/logo.webp" alt="logo" loading="lazy"></a>
</div>
</div>
<div class="col-xl-9 col-lg-9 col-md-8 text-right">
<div class="meinmenu">
<nav id="mobile-menu">
<ul>
<li><a class="" href="https://www.pencilbox.edu.bd">home</a></li>
<li><a class="" href="https://www.pencilbox.edu.bd/courses">courses</a></li>
<li><a class="" href="https://www.pencilbox.edu.bd/workshop">workshop</a></li>
<li><a class="" href="https://www.pencilbox.edu.bd/rpl">RPL</a></li>




<li><a class="" href="https://www.pencilbox.edu.bd/seip">
<span class="seip-pu">S</span>
<span class="seip-bl">E</span>
<span class="seip-pu">I</span>
<span style="
                                        background-color: #524FA1;
                                        padding: 0 3px 0 3px;
                                        color: #fff;
                                        font-weight: bold;
                                        font-size: 17px;
                                        font-family: seipFont;
">P</span>
</a></li>
<li><a class="" href="https://www.pencilbox.edu.bd/blog">blog</a></li>
<li><a class="" href="https://www.pencilbox.edu.bd/contact">contact</a></li>
</ul>
</nav>
</div>
<div class="mobile-menu"></div>
</div>















</div>
</div>
</div>


<section id="errorHandling" class="wow fadeInUp" data-wow-delay=".2s" data-wow-offset="300">
<div class="container">
<div class="row justify-content-between">
<div class="col-lg-12 text-center mt-5">
<img src="../images/404.png" alt="">
<span class="display-1 d-block" style="color:black;">Opps!</span>
<div class="mb-4 lead">The page you are looking for was not found.</div>
<a class="btn btn-info btn-lg mb-5" href="https://www.pencilbox.edu.bd">Back To Home</a>
</div>
</div>
</div>
</section>


<div class="subscribe-area section-padding" id="subscribes">
<div class="container">
<div class="row">
<div class="col-xl-6 offset-xl-3 col-lg-8 offset-lg-2 col-md-8 offset-md-2 col-12">
<div class="subscribe-content text-center">
<h3>Subscribe to our Newsletter</h3>
<h6>Do not miss any exciting offers by PencilBox </h6>

<input type="hidden" name="_token" value="WnBTXqfBknwUdyfPsE6dOXjiDSDyHnrXCkKJhBeR"> <div class="g-recaptcha" data-sitekey="6LfuM44bAAAAALOjqfAtsvtLa2HHgZDhVZogGtLq" data-callback="onSubmit" data-size="invisible"></div>
<input type="email" name="subscribe" placeholder="enter your e-mail address" required="">
<button type="submit">subscribe</button>

</div>
</div>
</div>
</div>
</div>


<div class="footer-area section-padding">
<div class="container" style="width: 90% !important; padding-left: 8px !important; padding-right: 8px !important;">
<div class="row">
<div class="col-xl-3 col-lg-3 col-md-6">
<div class="single-widget">
<div class="footer-logo">
<a href="https://www.pencilbox.edu.bd"><img src="../images/logo.webp" alt="logo" loading="lazy"></a>
</div>
<p style="margin-left: 0px;">We are PencilBox Training Institute. We provide training in IT sector. Our mission is to provide international standard training in Bangladesh's IT sector and thereby helping the society to build up a skilled workforce.</p>
<br>
<div class="footer-social">
<a href="https://www.facebook.com/PencilBoxTraining" target="_blank"><i class="fab fa-facebook-f"></i></a>
<a href="https://www.instagram.com/pencilboxtraining" target="_blank"><i class="fab fa-instagram"></i></a>
<a href="https://www.linkedin.com/in/pencilboxtraining/" target="_blank"><i class="fab fa-linkedin-in"></i></a>
<a href="https://www.youtube.com/channel/UCC6nCMUuzYlpJQNd87euwmw" target="_blank"><i class="fab fa-youtube"></i></a>
</div>
</div>
</div>
<div class="col-xl-6 col-lg-6 col-md-6">
<div class="single-widget">
<h3 class="text-center">useful links</h3>
<div class="footer-menu" style="padding-left: 62px">
<ul>
<li><a href="https://www.pencilbox.edu.bd/courses">Course</a></li>
<li><a href="https://www.pencilbox.edu.bd/workshop">Workshop</a></li>
<li><a href="https://www.pencilbox.edu.bd/event">Event</a></li>
<li><a href="https://www.pencilbox.edu.bd/industrial">Industrial Attachment</a></li>
<li><a href="https://www.pencilbox.edu.bd/about-us">About Us</a></li>
<li><a href="https://www.pencilbox.edu.bd/mission-vision">Our Vision &amp; Mission</a></li>
<li><a href="https://www.pencilbox.edu.bd/trainer">Trainer</a></li>
<li><a href="https://www.pencilbox.edu.bd/album">Image Album</a></li>
<li><a href="https://www.pencilbox.edu.bd/career">Career</a></li>
<li><a href="https://www.pencilbox.edu.bd/faq">FAQ</a></li>
<li><a href="https://www.pencilbox.edu.bd/privacy-policy">Privacy &amp; Policy</a></li>
<li><a href="https://www.pencilbox.edu.bd/terms-and-condition">Terms &amp; Conditions</a></li>
<li><a href="https://www.pencilbox.edu.bd/reviews">Review</a></li>
</ul>
</div>
<div class="footer-love-image">
<a href="https://www.pencilbox.edu.bd">
<img width="100%" height="50px" src="../images/Web-Footer.jpeg" alt="footer-love-img" loading="lazy">
</a>
</div>
</div>
</div>
<div class="col-xl-3 col-lg-3 col-md-12">
<div class="single-widget">
<h3>get in touch</h3>


<p><i class="fas fa-map-marker-alt"></i><strong>Address:</strong> EDB Trade Centre (5th Floor),
93 Kazi Nazrul Islam Avenue, Dhaka-1215.</p>
<p><i class="fas fa-mobile-alt"></i><span><a href="tel:+8801714121719" style="color: #000;">+88 01714 121719</a></span></p>
<p><i class="fas fa-phone"></i><a href="tel:+880241010090" style="color: #000;">+88 02 41010090</a></p>
<p><i class="fas fa-envelope"></i><a href="/cdn-cgi/l/email-protection#2d44434b426d5d48434e44414f425503484958034f49" style="color: #000;"><span class="__cf_email__" data-cfemail="e58c8b838aa595808b868c89878a9dcb808190cb8781">[email&nbsp;protected]</span></a></p>
</div>
</div>
</div>
</div>
<div style="margin-bottom: -50px;">
<img width="100%" height="30px" src="../images/footer-ipay.webp" alt="footer-img" class="img-fluid" loading="lazy">
</div>
</div>
























<div class="copyright-area" style="padding: 6px 0 !important;">
<div class="container">
<div class="row">
<div class="col-xl-6 offset-xl-3">
<div class="copyright-content">
<p>Copyright 2023 © <a href="https://pencilbox.edu.bd" target="_blank"> PencilBox Training Institute.</a> All Rights Reserved. </p>
</div>
</div>
</div>
</div>
</div>


<button id="return_top" onclick="if (!window.__cfRLUnblockHandlers) return false; topFunction()" data-cf-modified-64c389be0a9e467db0b8a158-=""><img src="../images/pencilbox-06b.png" loading="lazy"></button>



<script data-cfasync="false" src="email-decode.min.js"></script><script src="jquery-1.12.4.min.js" type="64c389be0a9e467db0b8a158-text/javascript"></script>

<script src="popper.min.js" type="64c389be0a9e467db0b8a158-text/javascript"></script>

<script src="bootstrap.min.js" type="64c389be0a9e467db0b8a158-text/javascript"></script>

<script src="owl.carousel.min.js" type="64c389be0a9e467db0b8a158-text/javascript"></script>

<script src="isotope.pkgd.min.js" type="64c389be0a9e467db0b8a158-text/javascript"></script>

<script src="jquery.meanmenu1.min.js" type="64c389be0a9e467db0b8a158-text/javascript"></script>

<script src="ajax-form.js" type="64c389be0a9e467db0b8a158-text/javascript"></script>

<script src="wow.min.js" type="64c389be0a9e467db0b8a158-text/javascript"></script>

<script src="waypoints.min.js" type="64c389be0a9e467db0b8a158-text/javascript"></script>
<script src="jquery.counterup.min.js" type="64c389be0a9e467db0b8a158-text/javascript"></script>

<script src="imagesloaded.pkgd.min.js" type="64c389be0a9e467db0b8a158-text/javascript"></script>

<script src="jquery.magnific-popup.min.js" type="64c389be0a9e467db0b8a158-text/javascript"></script>

<script src="skill.bars.jquery.js" type="64c389be0a9e467db0b8a158-text/javascript"></script>


<script src="plugins.js" type="64c389be0a9e467db0b8a158-text/javascript"></script>

<script src="jquery.validate.min.js" type="64c389be0a9e467db0b8a158-text/javascript"></script>

<script src="main1.js" type="64c389be0a9e467db0b8a158-text/javascript"></script>

<script src="select2.min.js" type="64c389be0a9e467db0b8a158-text/javascript"></script>
<script src="datepicker.min.js" type="64c389be0a9e467db0b8a158-text/javascript"></script>
<script src="sweetalert.min.js" type="64c389be0a9e467db0b8a158-text/javascript"></script>
<script type="64c389be0a9e467db0b8a158-text/javascript" src="slick.min.js"></script>
<script type="64c389be0a9e467db0b8a158-text/javascript">

    $("input[name=payment_type]" ).on( "click", function() {
        var payment_type=  $(this).val();
        var amount="";
        if(payment_type==2){
            var grand_total=  Math.round(amount * 1.015); 
            var change_total= 1.5;
            $('#grand_total').val(grand_total);
            $('.grand_total').text(grand_total);
            $('.change_total').text(change_total);
       }else if(payment_type==3){
        
            var grand_total=  Math.round(amount * 1.014); 
            var change_total= 1.4;
            $('.grand_total').val(grand_total);
            $('.grand_total').text(grand_total);
            $('.change_total').text(change_total);
        }else{
            var grand_total=  Math.round(amount * 1.026);
            var change_total= 2.6; 
            $('#grand_total').val(grand_total);
            $('.grand_total').text(grand_total);
            $('.change_total').text(change_total);
       }
    });
    $('input:radio[name=payment_type]:checked').each(function() 
    {
       var payment_type=  $(this).val();
       var amount="";
       if(payment_type==2){
             var grand_total=  Math.round(amount * 1.015); 
             var change_total= 1.5;
            $('.grand_total').val(grand_total);
            $('.grand_total').text(grand_total);
            $('.change_total').text(change_total);
       }else if(payment_type==3){
        
            var grand_total=  Math.round(amount * 1.014); 
             var change_total= 1.4;
            $('.grand_total').val(grand_total);
            $('.grand_total').text(grand_total);
            $('.change_total').text(change_total);
       }else{
            var grand_total=  Math.round(amount * 1.026);
            var change_total= 2.6; 
            $('.grand_total').val(grand_total);
            $('.grand_total').text(grand_total);
            $('.change_total').text(change_total);
       }
    });
</script>
<script type="64c389be0a9e467db0b8a158-text/javascript">


$("#reg_student_phone_number").keydown(function(e) {
    var oldvalue=$(this).val();
    var field=this;
    setTimeout(function () {
        if(field.value.indexOf('01') !== 0) {
            $(field).val(oldvalue);
        } 
    }, 1);
});
    $(document).ready(function () {
        // $('body').scrollTo('#pencilbox_home_slider_down_counter');
        $('.count_homepage').each(function () {
        $(this).prop('Counter',0).animate({
            Counter: $(this).text()
        }, {
            duration: 4000,
            easing: 'swing',
            step: function (now) {
                $(this).text(Math.ceil(now));
            }
        });
    });
        
        $('.select_seip').select2();
        $('#birthday').datepicker();

        $("#afterRegistrationContinue").hide();
        // $("#afterRegistrationContinueFromCourse").hide();
        // $("#afterRegistrationContinueFromCourseTop").hide();
        $('.registration_second_half').hide();
        $("#paymentConfirmShow").hide();
        $("#paymentConfirmShowL").hide();
        $("#paymentCongratulationShowCartPage").hide();
        $("#partialPaymentForm").hide();
        $("#partialPaymentFormL").hide();
        $("#partialPaymentFormD").hide();
        $(".create_an_account_email_field").hide();

        //Course Apply
        $(".pencilbox_apply_course_login").hide();
        $(".pencilbox_apply_course_registration").hide();

        $("#employee_Student").hide();
        $("#employee_Freelancer").hide();
        $("#employee_Businessman").hide();
        $("#employee_Entrepreneur").hide();
        $("#employee_Job_Seeker").hide();
        $("#employee_Job_Holder").hide();
        $("#field_of_interest_alternative_raw").hide();
        $("#field_of_interest_alternative").prop('required', false);
        $('#national_id').prop('required', true);
        $('#birth_id').prop('required', true);

        var current_fs, next_fs, previous_fs; //fieldsets
        var opacity;
        var current = 1;
        var steps = $("fieldset").length;

        setProgressBar(current);

        $('#national_id, #birth_id').change(function() {
            var national_id = $('#national_id').val();
            var birth_id = $('#birth_id').val();
            if(national_id != '') {
                $('#birth_id').prop('required', false);
                $('#birth_id-error').hide();
                $('#birth_id').removeClass('error');
                $('#national_id').prop('required', true);
                $('.national_id_label').html("National ID: *");
                $('.birth_id_label').html("Birth Certificate ID: (Optional)");
            } else if(birth_id != '') {
                $('#birth_id').prop('required', true);
                $('#national_id').prop('required', false);
                $('#national_id').removeClass('error');
                $('#national_id-error').hide();
                $('.birth_id_label').html("Birth Certificate ID: *");
                $('.national_id_label').html("National ID: (Optional)");
            } else {
                $('#birth_id').prop('required', true);
                $('#national_id').prop('required', true);
                $('#national_id-error').show();
                $('#birth_id-error').show();
                $('.national_id_label').html("National ID: *");
                $('.birth_id_label').html("Birth Certificate ID: *");
            }
        });

        function fnCalculateAge(){
             // let userDateinput = document.getElementById("birthday").value;

            let td = document.getElementById("birthday").value.slice(0, 2);
            let tm = document.getElementById("birthday").value.slice(3, 5);
            let ty = document.getElementById("birthday").value.slice(6, 10);

            let userDateinput = tm + "/" + td + "/" + ty;

             // convert user input value into date object
            let birthDate = new Date(userDateinput);

        	 // get difference from current date;
            let difference = Date.now() - birthDate.getTime();
            // console.log(formatDate(d, "dddd h:mmtt d MMM yyyy"));

            let ageDate = new Date(difference);

        	 return Math.abs(ageDate.getUTCFullYear() - 1970);
            }

        var prev_val;
        $('#course_name').focus(function() {
            prev_val = $(this).val();
        }).change(function(e) {
        var select = this;
        $(this).blur();
        // var current = $(this).find(":selected").text();
            if($(this).hasClass('valid')) {
                return swal({
                    title: "Caution!",
                    text: "Are you sure you want to Change your choice?",
                    icon: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#239024",
                    cancelButtonColor: "#ff2e04",
                    buttons: [
                        'No, cancel it!',
                        'Yes, I am sure!'
                    ],
                }).then(function(isConfirm) {
                    if (isConfirm) {
                        e.preventDefault();
                        return true;
                    } else {
                        $(select).val(prev_val); //set back
                        return false;
                    }
                });
                // if(!confirm('Are you sure you want to Change your choice?')) {
                // }
            }
        });

    // $("#personal_info_check").click(function() {
    $("#education_check").click(function() {
      var form = $("#msform");

    topFunction();
      if (form.valid() === true) {
          if($("#national_id").val().length != 0 && $("#national_id").val().length != 10 && $("#national_id").val().length != 13 && $("#national_id").val().length != 17) {
              swal({
                  title: "Warning!",
                  text: 'National ID Must be 10, 13, 17 digit. You are given ' + $("#national_id").val().length + ' Digit!',
                  icon: "error"
              });
                $('#national_id').removeClass('valid');
                $('#national_id').addClass('error');
                $('#national_id-error').show();
          } else if($("#birth_id").val().length != 0 && $("#birth_id").val().length != 10 && $("#birth_id").val().length != 13 && $("#birth_id").val().length != 17) {
              swal({
                  title: "Warning!",
                  text: 'Birth ID Must be 10, 13, 17 digit. You are given ' + $("#birth_id").val().length + ' Digit!',
                  icon: "error"
              });
                $('#birth_id').removeClass('valid');
                $('#birth_id').addClass('error');
                $('#birth_id-error').show();
          } else if($("#phone").val().length != 11 || $("#phone").val().charAt(0) != 0 || $("#phone").val().charAt(1) != 1) {
              swal({
                  title: "Warning!",
                  text: 'Mobile Number not valid',
                  icon: "error"
              });
                $('#phone').removeClass('valid');
                $('#phone').addClass('error');
                $('#phone-error').show();
          } else if(fnCalculateAge() < 18) {
              swal({
                  title: "Warning!",
                  text: 'You are ' + fnCalculateAge() + ' years old. You must be at least 18 years old to continue',
                  icon: "error"
              });
                $('#birthday').removeClass('valid');
                $('#birthday').addClass('error');
                $('#birthday-error').show();
          } else {
                current_fs = $(this).parent();
                next_fs = $(this).parent().next();
//show the next fieldset
            next_fs.show();
//hide the current fieldset with style
            current_fs.animate({opacity: 0}, {
                step: function (now) {
// for making fielset appear animation
                    opacity = 1 - now;

                    current_fs.css({
                        'display': 'none',
                        'position': 'relative'
                    });
                    next_fs.css({'opacity': opacity});
                },
                duration: 500
            });
            setProgressBar(++current);

            $('#tbl_course_name').html($('#course_name :selected').text());
            $('#tbl_full_name').html($('#full_name').val());
            // $('#tbl_father_name').html($('#father_name').val());
            // $('#tbl_mother_name').html($('#mother_name').val());
            $('#tbl_religion').html($('#religion :selected').text());
            $('#tbl_gender').html($('#gender :selected').text());
            // $('#tbl_ethnic_group').html($('#ethnic_group :selected').text());
            $('#tbl_birthday').html($('#birthday').val());
            $('#tbl_national_id').html($('#national_id').val());
            // $('#tbl_birth_id').html($('#birth_id').val());
            $('#tbl_phone').html($('#phone').val());
            $('#tbl_email').html($('#email').val());
          }
  }});

    // $("#address_check").click(function() {
    $("#education_check").click(function() {
      var form = $("#msform");
      topFunction();

      if (form.valid() === true) {
          current_fs = $(this).parent();
          next_fs = $(this).parent().next();

//Add Class Active
            $("#progressbar li").eq($("fieldset").index(next_fs)).addClass("active");

//show the next fieldset
            next_fs.show();
//hide the current fieldset with style
            current_fs.animate({opacity: 0}, {
                step: function (now) {
// for making fielset appear animation
                    opacity = 1 - now;

                    current_fs.css({
                        'display': 'none',
                        'position': 'relative'
                    });
                    next_fs.css({'opacity': opacity});
                },
                duration: 500
            });
            setProgressBar(++current);


            $('#tbl_course_name').html($('#course_name :selected').text());
            $('#tbl_present_address').html($('#present_address').val());
            $('#tbl_present_city').html($('#present_city').val());
            $('#tbl_present_postal_code').html($('#present_postal_code').val());
            
            $('#tbl_pres_division').html($('#_pres_division').val());
            $('#tbl_pres_district').html($('#_pres_district').val());
            $('#tbl_pre_sub_district').html($('#_pre_sub_district').val());
            
            // $('#tbl_pres_division').html($('#pres_division :selected').text());
            // $('#tbl_pres_district').html($('#pres_district :selected').text());
            // $('#tbl_pre_sub_district').html($('#pre_sub_district :selected').text());
            // if($('#same_as_present').prop("checked")) {
            //     $('#tbl_permanent_address').html($('#present_address').val());
            //     $('#tbl_permanent_city').html($('#present_city').val());
            //     $('#tbl_permanent_postal_code').html($('#present_postal_code').val());
            //     $('#tbl_per_division').html($('#pres_division :selected').text());
            //     $('#tbl_per_district').html($('#pres_district :selected').text());
            //     $('#tbl_per_sub_district').html($('#pre_sub_district :selected').text());
            // } else {
            //     $('#tbl_permanent_address').html($('#permanent_address').val());
            //     $('#tbl_permanent_city').html($('#permanent_city').val());
            //     $('#tbl_permanent_postal_code').html($('#permanent_postal_code').val());
            //     $('#tbl_per_division').html($('#per_division :selected').text());
            //     $('#tbl_per_district').html($('#per_district :selected').text());
            //     $('#tbl_per_sub_district').html($('#per_sub_district :selected').text());
            // }
  }});

    $("#education_check").click(function() {
      var form = $("#msform");
      topFunction();

      if (form.valid() === true) {

        $('#course_name_div').hide();
        $('#msform fieldset:nth-child(-n+3)').hide();
          current_fs = $(this).parent();
          next_fs = $(this).parent().next();

//Add Class Active
            $("#progressbar li").eq($("fieldset").index(next_fs)).addClass("active");

//show the next fieldset
            next_fs.show();
//hide the current fieldset with style
            current_fs.animate({opacity: 0}, {
                step: function (now) {
// for making fielset appear animation
                    opacity = 1 - now;

                    current_fs.css({
                        'display': 'none',
                        'position': 'relative'
                    });
                    next_fs.css({'opacity': opacity});
                },
                duration: 500
            });
            setProgressBar(++current);

            $('#tbl_course_name').html($('#course_name :selected').text());
            if($('#institute_name :selected').val() == "Others") {
                $('#tbl_institute_name').html($('#other_institute_name').val());
            } else {
                $('#tbl_institute_name').html($('#institute_name').val());
            }
            $('#tbl_subject').html($('#subject').val());
            $('#tbl_passing_year').html($('#passing_year').val());
            $('#tbl_lavel_of_education').html($('#lavel_of_education :selected').text());
  }
    });

    $('#msform').submit(function (e) {
        e.preventDefault();
        $('#preloader-active').show();
        var formData = new FormData(this);
            // if (formData.valid() === true) {
                $.ajax({
                        type: "POST",
                        url: "https://seip.pencilbox.edu.bd/user-add",
                        data: formData,
                        success: function(value) {
                            console.log(value);
                            if(value.status) {
                            $('#preloader-active').hide();
                            topFunction();
                            swal({
                                title: "Congratulations!",
                                text: value.message,
                                icon: "success"
                            });
//                            toastr.success();
                            $('#course_name_div').hide();
                            $('.registration-success').html("Your Registration has been successful.");
                            $('.registration-success-id').html("Your SEID Number is PB" + value.seip_id);
                            $('.registration-success-pre').html("Please preserve this number for future reference. We already sent an Email to your email and SMS to your phone number.");
                            current_fs = $('#submit_form').parent();
                            next_fs = $('#submit_form').parent().next();

                            //Add Class Active
                            $("#progressbar li").eq($("fieldset").index(next_fs)).addClass("active");

                            //show the next fieldset
                            next_fs.show();
                            //hide the current fieldset with style
                            current_fs.animate({opacity: 0}, {
                                step: function (now) {
                                    // for making fielset appear animation
                                    opacity = 1 - now;

                                    current_fs.css({
                                        'display': 'none',
                                        'position': 'relative'
                                    });
                                    next_fs.css({'opacity': opacity});
                                },
                                duration: 500
                            });
                            setProgressBar(++current);
                            } else {

                            $('#preloader-active').hide();

                                swal({
                                    title: "Warning!",
                                    text: value.message,
                                    icon: "error"
                                });
//                            toastr.error(value.message);
                            }
                        },
                        error: function(error){
                            console.log(error);
                            $('#preloader-active').hide();
                            swal({
                                title: "Warning!",
                                text: error.message,
                                icon: "error"
                            });
//                            toastr.error(error.message);
                        },
                        cache: false,
                        contentType: false,
                        processData: false
                    });
            // }
            // else {
            //     alert('Please Filled all require field');
            // }
        });

        $(".previous").click(function () {
             topFunction();
            current_fs = $(this).parent();
            previous_fs = $(this).parent().prev();

//Remove class active
            $("#progressbar li").eq($("fieldset").index(current_fs)).removeClass("active");

//show the previous fieldset
            previous_fs.show();

//hide the current fieldset with style
            current_fs.animate({opacity: 0}, {
                step: function (now) {
// for making fielset appear animation
                    opacity = 1 - now;

                    current_fs.css({
                        'display': 'none',
                        'position': 'relative'
                    });
                    previous_fs.css({'opacity': opacity});
                },
                duration: 500
            });
            setProgressBar(--current);
        });

        function setProgressBar(curStep) {
            var percent = parseFloat(100 / steps) * curStep;
            percent = percent.toFixed();
            $(".progress-bar")
                .css("width", percent + "%")
        }

        $(".submit").click(function () {
            return false;
        })

    });

    $('#field_of_interest').change(function () {
        if ($(this).val() == "Other") {
            $("#field_of_interest_alternative_raw").show();
            $("#field_of_interest_alternative").prop('required', true);
        } else {
            $("#field_of_interest_alternative_raw").hide();
            $("#field_of_interest_alternative").prop('required', false);
        }
    });

        $(".review_previous").click(function () {

            $('#course_name_div').show();
             topFunction();
             
            $('#msform fieldset:nth-child(-n+3)').show();
            $('#msform fieldset:nth-last-child(-n+2)').hide();
            
            current_fs = $(this).parent();
            previous_fs = $(this).parent().prev();

//Remove class active
            $("#progressbar li").eq($("fieldset").index(current_fs)).removeClass("active");

//show the previous fieldset
            previous_fs.show();

//hide the current fieldset with style
            current_fs.animate({opacity: 0}, {
                step: function (now) {
// for making fielset appear animation
                    opacity = 1 - now;

                    current_fs.css({
                        'display': 'none',
                        'position': 'relative'
                    });
                    previous_fs.css({'opacity': opacity});
                },
                duration: 500
            });
            setProgressBar(--current);
        });

    $('#employment_status').on('change', function () {
        if ($(this).val() === "Student") {
            $("#employee_Student").show();
            $("#employee_Freelancer").hide();
            $("#employee_Businessman").hide();
            $("#employee_Entrepreneur").hide();
            $("#employee_Job_Seeker").hide();
            $("#employee_Job_Holder").hide();

            $('#current_institute').prop('required', true);
            $('#semester').prop('required', true);

            $('#marketplace_link').prop('required', false);

            $('#type_of_business').prop('required', false);

            $('#entrepreneur_working_sector').prop('required', false);

            $('#field_of_interest').prop('required', false);

            $('#company_name').prop('required', false);
            $('#designation').prop('required', false);
        } else if ($(this).val() === "Freelancer") {
            $("#employee_Student").hide();
            $("#employee_Freelancer").show();
            $("#employee_Businessman").hide();
            $("#employee_Entrepreneur").hide();
            $("#employee_Job_Seeker").hide();
            $("#employee_Job_Holder").hide();

            $('#current_institute').prop('required', false);
            $('#semester').prop('required', false);

            $('#marketplace_link').prop('required', true);

            $('#type_of_business').prop('required', false);

            $('#entrepreneur_working_sector').prop('required', false);

            $('#field_of_interest').prop('required', false);

            $('#company_name').prop('required', false);
            $('#designation').prop('required', false);
        } else if ($(this).val() === "Businessman") {
            $("#employee_Student").hide();
            $("#employee_Freelancer").hide();
            $("#employee_Businessman").show();
            $("#employee_Entrepreneur").hide();
            $("#employee_Job_Seeker").hide();
            $("#employee_Job_Holder").hide();

            $('#current_institute').prop('required', false);
            $('#semester').prop('required', false);

            $('#marketplace_link').prop('required', false);

            $('#type_of_business').prop('required', true);

            $('#entrepreneur_working_sector').prop('required', false);

            $('#field_of_interest').prop('required', false);

            $('#company_name').prop('required', false);
            $('#designation').prop('required', false);
        } else if ($(this).val() === "Entrepreneur") {
            $("#employee_Student").hide();
            $("#employee_Freelancer").hide();
            $("#employee_Businessman").hide();
            $("#employee_Entrepreneur").show();
            $("#employee_Job_Seeker").hide();
            $("#employee_Job_Holder").hide();

            $('#current_institute').prop('required', false);
            $('#semester').prop('required', false);

            $('#marketplace_link').prop('required', false);

            $('#type_of_business').prop('required', false);

            $('#entrepreneur_working_sector').prop('required', true);

            $('#field_of_interest').prop('required', false);

            $('#company_name').prop('required', false);
            $('#designation').prop('required', false);
        } else if ($(this).val() === "Job_Seeker") {
            $("#employee_Student").hide();
            $("#employee_Freelancer").hide();
            $("#employee_Businessman").hide();
            $("#employee_Entrepreneur").hide();
            $("#employee_Job_Seeker").show();
            $("#employee_Job_Holder").hide();

            $('#current_institute').prop('required', false);
            $('#semester').prop('required', false);

            $('#marketplace_link').prop('required', false);

            $('#type_of_business').prop('required', false);

            $('#entrepreneur_working_sector').prop('required', false);

            $('#field_of_interest').prop('required', true);

            $('#company_name').prop('required', false);
            $('#designation').prop('required', false);
        } else if ($(this).val() === "Job_Holder") {
            $("#employee_Student").hide();
            $("#employee_Freelancer").hide();
            $("#employee_Businessman").hide();
            $("#employee_Entrepreneur").hide();
            $("#employee_Job_Seeker").hide();
            $("#employee_Job_Holder").show();

            $('#current_institute').prop('required', false);
            $('#semester').prop('required', false);

            $('#marketplace_link').prop('required', false);

            $('#type_of_business').prop('required', false);

            $('#entrepreneur_working_sector').prop('required', false);

            $('#field_of_interest').prop('required', false);

            $('#company_name').prop('required', true);
            $('#designation').prop('required', true);
        }
        // else {
        //     $("#employee_Student").hide();
        //     $("#employee_Freelancer").hide();
        //     $("#employee_Businessman").hide();
        //     $("#employee_Entrepreneur").hide();
        //     $("#employee_Job_Seeker").hide();
        //     $("#employee_Job_Holder").hide();

        //     $('#current_institute').prop('required', false);
        //     $('#semester').prop('required', false);

        //     $('#marketplace_link').prop('required', false);

        //     $('#type_of_business').prop('required', false);

        //     $('#entrepreneur_working_sector').prop('required', false);

        //     $('#field_of_interest').prop('required', false);

        //     $('#company_name').prop('required', false);
        //     $('#designation').prop('required', false);
        // }
    });

    $('#same_as_present').click(function () {
        if($(this).prop("checked")) {
            $('.permanent_address_div').hide();
            $("#per_division").prop("disabled", true);
            $("#per_division").prop("required", false);
            $("#per_district").prop("disabled", true);
            $("#per_district").prop("required", false);
            $("#per_sub_district").prop("disabled", true);
            $("#per_sub_district").prop("required", false);
            $("#permanent_address").prop("readonly", true);
            $("#permanent_address").prop("required", false);
            $("#permanent_city").prop("readonly", true);
            $("#permanent_city").prop("required", false);
            $("#permanent_postal_code").prop("readonly", true);
            $("#permanent_postal_code").prop("required", false);

            $("#permanent_address").val($('#present_address').val());
            $("#permanent_city").val($('#present_city').val());
            $("#permanent_postal_code").val($('#present_postal_code').val());
            $("#per_division").val($('#pres_division').val());
        } else {
            $('.permanent_address_div').show();
            $("#per_division").prop("disabled", false);
            $("#per_division").prop("required", true);
            $("#per_district").prop("disabled", false);
            $("#per_district").prop("required", true);
            $("#per_sub_district").prop("disabled", false);
            $("#per_sub_district").prop("required", true);
            $("#permanent_address").prop("readonly", false);
            $("#permanent_address").prop("required", true);
            $("#permanent_city").prop("readonly", false);
            $("#permanent_city").prop("required", true);
            $("#permanent_postal_code").prop("readonly", false);
            $("#permanent_postal_code").prop("required", true);

            $("#permanent_address").val("");
            $("#permanent_city").val("");
            $("#permanent_postal_code").val("");
            $('#per_district').empty();
            $('#per_sub_district').empty();
        }
    });

    // load the district from Ajax call for Present Address
// $('#lavel_of_education').change(function () {
//     if($(this).val() == 'HSC/Alim/Equivalent') {
//         $('#institute_name').prop('required', true);
//         $('.other_institute_name').hide();
//         $('#other_institute_name').prop('required', false);
//         var university = "https://seip.pencilbox.edu.bd/boards";
//         $('.ssc_disabled').show();
//     } else if($(this).val() == 'SSC/Dakhil/Equivalent') {
//             $('#institute_name').prop('required', true);
//             $('#institute_name').empty();
//             $('.other_institute_name').hide();
//             $('#other_institute_name').prop('required', true);
//             $('#institute_name').append('<option disabled selected="selected">You can\'t Apply</option>');
//             $('.ssc_disabled').hide();
//             swal({
//                 title: "Warning!",
//                 text: "You aren't eligible apply for this project!",
//                 icon: "warning"
//             });
//             return;
//     } else if($(this).val() == 'Diploma') {
//             $('#other_institute_name').prop('required', false);
//             $('.other_institute_name').hide();
//             var university = "https://seip.pencilbox.edu.bd/politechnics";
//             $('.ssc_disabled').show();
//     } else {
//         $('#institute_name').prop('required', true);
//         $('.other_institute_name').hide();
//         $('#other_institute_name').prop('required', false);
//         var university = "https://seip.pencilbox.edu.bd/universities";
//         $('.ssc_disabled').show();
//     }
//     $('#institute_name').empty();
//     $('#preloader-active').show();
//     $.ajax({
//         type: "GET",
//         url: university,
//         dataType: "json",
//         success: function (data) {
//             $('#institute_name').append('<option disabled selected="selected">Select One</option>');
//             for (var i = 0; i < data.length; i++) {
//                 $("#institute_name").append('<option value="' + data[i].university_name + '">' + data[i].university_name + '</option>');
//             }
//             $('#preloader-active').hide();
//         }
//     });
// });

$('#registration_first_half_btn').click(function(e) {
    e.preventDefault();
    let formData = $('#apply_now_registration_apply_page');
    if (formData.valid() === true) {
        $('.registration_first_half').hide();
        $('.registration_second_half').show();
    }
});

$('#registrationContinueBtnCartPage').click(function(e) {
    e.preventDefault();
    $('#preloader-active').show();
    let formData = $('#apply_now_form');
    if (formData.valid() === true) {
        $.ajax({
            url: "https://www.pencilbox.edu.bd/register/new-course",
            type: "POST",
            data: $(formData).serialize(),
            success: function(resp) {
            $('.error_msg').remove();
                if(resp.errors){
                    $('#preloader-active').hide();
                    // $('#email_address_er').html(resp.errors.email_address);
                    // $('#phone_number_er').html(resp.errors.phone_number);
                    // $('#recaptcha_er').html(resp.errors.g-recaptcha-response);
                    // $('#recaptcha_er').html(resp.errors);
                    $.each(resp.errors,function(key,value){
                            $( `<span class="error_msg text-danger" style="font-size:12px;">${value[0]}</span>` ).insertAfter('[name="'+key+'"]' );
                    })
                     
                    
                }else{
                    $('#preloader-active').hide();
                    if(resp.after_only_course_registration == 'not_success') {
                        swal({
                            title: "Warning!",
                            text: "You have already registered for this course! Please apply for another one.",
                            icon: "warning"
                        });
                    } else {
                        $('#courseRegistration_id_apply_course').val(resp.non_login_courseRegistration_id)
                        $('#pencilbox_apply_course_main').hide();
                        $('#paymentCongratulationShowCartPage').show();
                    }
                }
                    
                }
                
        });
    } else { 
        
        $('#preloader-active').hide();
    }
});

// load the district from Ajax call for Present Address


// $('#institute_name').change(function () {
//     //var a = $('#division option:selected').text();
//     var institute_name = $('#institute_name').val();
//     if(institute_name == "Others") {
//         $('.other_institute_name').show();
//         $('#other_institute_name').prop('required', true);
//     } else {
//         $('.other_institute_name').hide();
//         $('#other_institute_name').prop('required', false);
//     }
// });

$('#create_an_account_training').click(function () {
    if($('#create_an_account_training').prop("checked")) {
            $('.create_an_account_email_field').show();
    } else {
            $('.create_an_account_email_field').hide();
        }
});

$('#email_address_registration').focusout(function () {
    var email_address_pre_registration_course = $(this).val();
    $.ajax({
        url: '/student-email-check-registration',
        type: "post",
        data: { 
            "_token": "WnBTXqfBknwUdyfPsE6dOXjiDSDyHnrXCkKJhBeR",
            "email": email_address_pre_registration_course
            },
        success: function(data) {
            if (data == 1) {
                $(".email_address_pre_registration_course_error").show();
                $(".email_address_pre_registration_course_error").html('This email already registered.');
            } else {
                $("#email_address_registration").val(data);
                $(".email_address_pre_registration_course_error").hide();
            }

        }
    });
});

$('#email_address_registration_top').focusout(function () {
    var email_address_pre_registration_course = $(this).val();
    $.ajax({
        url: '/student-email-check-registration',
        type: "post",
        data: { 
            "_token": "WnBTXqfBknwUdyfPsE6dOXjiDSDyHnrXCkKJhBeR",
            "email": email_address_pre_registration_course
            },
        success: function(data) {
            if (data == 1) {
                $(".email_address_pre_registration_course_error").show();
                $(".email_address_pre_registration_course_error").html('This email already registered.');
            } else {
                $("#email_address_registration_top").val(data);
                $(".email_address_pre_registration_course_error").hide();
            }

        }
    });
});

$('#username_registration').focusout(function () {
    var username_registration = $(this).val();
    $.ajax({
        url: '/student-username-check-registration',
        type: "post",
        data: { 
            "_token": "WnBTXqfBknwUdyfPsE6dOXjiDSDyHnrXCkKJhBeR",
            "username": username_registration
            },
        success: function(data) {
            if (data == 1) {
                $(".username_registration_course_error").show();
                $(".username_registration_course_error").html('This username already been taken.');
            } else {
                $("#username_registration").val(data);
                $(".username_registration_course_error").hide();
            }

        }
    });
});

$('#username_registration_top').focusout(function () {
    var username_registration = $(this).val();
    $.ajax({
        url: '/student-username-check-registration',
        type: "post",
        data: { 
            "_token": "WnBTXqfBknwUdyfPsE6dOXjiDSDyHnrXCkKJhBeR",
            "username": username_registration
            },
        success: function(data) {
            if (data == 1) {
                $(".username_registration_course_error").show();
                $(".username_registration_course_error").html('This username already been taken.');
            } else {
                $("#username_registration_top").val(data);
                $(".username_registration_course_error").hide();
            }

        }
    });
});

$('#confirm_password_registration_course, #password_registration_course').keyup(function () {
    let confirm_password_registration_course = $('#confirm_password_registration_course').val();
    let password_registration_course = $('#password_registration_course').val();
    if (confirm_password_registration_course != password_registration_course) {
        $(".password_registration_course_error").show();
        $(".password_registration_course_error").html('Confirm password not match!');
    } else {
        $(".password_registration_course_error").hide();
    }
});

$('#confirm_password_top, #password_top').keyup(function () {
    let confirm_password_registration_course = $('#confirm_password_top').val();
    let password_registration_course = $('#password_top').val();
    if (confirm_password_registration_course != password_registration_course) {
        $(".password_registration_course_error").show();
        $(".password_registration_course_error").html('Confirm password not match!');
    } else {
        $(".password_registration_course_error").hide();
    }
});

$('#paymentCongratulationBtn').click(function () {
    $("#paymentCongratulationShow").hide();
    $("#paymentCongratulationShowCartPage").hide();
    $("#paymentConfirmShow").show();
});

$('#paymentCongratulationBtnL').click(function () {
    $("#paymentCongratulationShowL").hide();
    $("#paymentConfirmShowL").show();
});

$('#paymentCongratulationBtnD').click(function () {
    $("#paymentCongratulationShowD").hide();
    $("#paymentConfirmShowD").show();
});

// $('#partialPaymentBtn').click(function () {
//     if ($("#partialPaymentForm").css('display') == 'none') {
//         $("#partialPaymentForm").show();
//         $("#partialPaymentBtn").html('Pay full amount');
//     } else {
//         $("#partialPaymentForm").hide();
//         $("#partialPaymentBtn").html('Pay partial amount');
//     }
// });

// $('#partialPaymentBtnL').click(function () {
//     if ($("#partialPaymentFormL").css('display') == 'none') {
//         $("#partialPaymentFormL").show();
//         $("#partialPaymentBtnL").html('Pay full amount');
//     } else {
//         $("#partialPaymentFormL").hide();
//         $("#partialPaymentBtnL").html('Pay partial amount');
//     }
// });

// $('#partialPaymentBtnD').click(function () {
//     if ($("#partialPaymentFormD").css('display') == 'none') {
//         $("#partialPaymentFormD").show();
//         $("#partialPaymentBtnD").html('Pay full amount');
//     } else {
//         $("#partialPaymentFormD").hide();
//         $("#partialPaymentBtnD").html('Pay partial amount');
//     }
// });

//Apply course
    $("#pencilbox_apply_course_login_show").click(function (e) {
        e.preventDefault();
        $("#registration_login_course_type").val(2);
        $("#pencilbox_apply_course_login").show();
        $("#pencilbox_apply_course_main").hide();
        $("#pencilbox_apply_course_registration").hide();
    });
    
    $("#pencilbox_apply_course_login_show_registration").click(function (e) {
        e.preventDefault();
        $("#registration_login_course_type").val(2);
        $("#pencilbox_apply_course_login").show();
        $("#pencilbox_apply_course_main").hide();
        $("#pencilbox_apply_course_registration").hide();
    });

    $("#pencilbox_apply_course_registration_show").click(function (e) {
        e.preventDefault();
        $("#registration_login_course_type").val(3);
        $("#pencilbox_apply_course_login").hide();
        $("#pencilbox_apply_course_main").hide();
        $("#pencilbox_apply_course_registration").show();
    });

    $("#pencilbox_apply_course_registration_show_from_login").click(function (e) {
        e.preventDefault();
        $("#registration_login_course_type").val(3);
        $("#pencilbox_apply_course_login").hide();
        $("#pencilbox_apply_course_main").hide();
        $("#pencilbox_apply_course_registration").show();
    });

    $("#revert_back_to_main_course_from_login").click(function () {
        $("#registration_login_course_type").val(1);
        $("#pencilbox_apply_course_login").hide();
        $("#pencilbox_apply_course_main").show();
        $("#pencilbox_apply_course_registration").hide();
    });

    $("#revert_back_to_main_course_from_pay_online").click(function () {
        $("#paymentConfirmShow").hide();
        $("#paymentCongratulationShowCartPage").show();
        $("#paymentCongratulationShow").show();
    });

    $("#revert_back_to_main_course_from_dashboard").click(function () {
        $("#paymentConfirmShowL").hide();
        $("#paymentCongratulationShowL").show();
    });

    $("#revert_back_to_main_course_from_dashboard_D").click(function () {
        $("#paymentConfirmShowD").hide();
        $("#paymentCongratulationShowD").show();
    });

    $("#revert_back_to_main_course_from_register").click(function () {
        $("#registration_login_course_type").val(1);
        $("#pencilbox_apply_course_login").hide();
        $("#pencilbox_apply_course_main").show();
        $("#pencilbox_apply_course_registration").hide();
    });

// load the district from Ajax call for Present Address
$('#pres_division').change(function () {
    //var a = $('#division option:selected').text();
    $('#preloader-active').show();
    var division_id = $('#pres_division').val();
    $('#pres_district').empty();
    $.ajax({
        type: "GET",
        url: "https://seip.pencilbox.edu.bd/districts",
        data: {division_id: division_id},
        dataType: "json",
        success: function (data) {
            $('#pres_district').append('<option value="0" selected="selected">Select District</option>');
            for (var i = 0; i < data.length; i++) {
                if(division_id == data[i].division_id){
                    $("#pres_district").append('<option value="' + data[i].id + '">' + data[i].name + '</option>');
                }
            }

            $('#preloader-active').hide();
        }
    });
});
// load the Sub district from Ajax call for Present Address
$('#pres_district').change(function () {
    //var c = $('#district option:selected').text();
    $('#preloader-active').show();
    var district_id = $('#pres_district').val();
    $('#pre_sub_district').empty();
    $.ajax({
        type: "GET",
        url: "https://seip.pencilbox.edu.bd/sub-districts",
        data: {district_id: district_id},
        dataType: "json",
        success: function (data) {
            $('#pre_sub_district').append('<option value="0" selected="selected">Select Upazila</option>');
            for (var i = 0; i < data.length; i++) {
                if(district_id == data[i].district_id){
                    $("#pre_sub_district").append('<option value="' + data[i].id + '">' + data[i].name + '</option>');
                }
            }
            $('#preloader-active').hide();
        }
    });
});

// load the district from Ajax call for Present Address

$('#per_division').change(function () {
    //var a = $('#division option:selected').text();
    $('#preloader-active').show();
    var division_id = $('#per_division').val();
    $('#per_district').empty();
    $.ajax({
        type: "GET",
        url: "https://seip.pencilbox.edu.bd/districts",
        data: {division_id: division_id},
        dataType: "json",
        success: function (data) {
            $('#per_district').append('<option value="0" selected="selected">Select District</option>');
            for (var i = 0; i < data.length; i++) {
                if(division_id == data[i].division_id){
                    $("#per_district").append('<option value="' + data[i].id + '">' + data[i].name + '</option>');
                }
            }
            $('#preloader-active').hide();
        }
    });
});

// load the sub district from Ajax call for permanent Address
$('#per_district').change(function () {
    //var c = $('#district option:selected').text();
    $('#preloader-active').show();
    var district_id = $('#per_district').val();
    $('#per_sub_district').empty();
    $.ajax({
        type: "GET",
        url: "https://seip.pencilbox.edu.bd/sub-districts",
        data: {district_id: district_id},
        dataType: "json",
        success: function (data) {
            $('#per_sub_district').append('<option value="0" selected="selected">Select Upazila</option>');
            for (var i = 0; i < data.length; i++) {
                if(district_id == data[i].district_id){
                    $("#per_sub_district").append('<option value="' + data[i].id + '">' + data[i].name + '</option>');
                }
            }
            $('#preloader-active').hide();
        }
    });
});
</script>
<script type="64c389be0a9e467db0b8a158-text/javascript">


    function openSearch() {
        document.getElementById("myOverlay").style.display = "block";
    }

    function closeSearch() {
        document.getElementById("myOverlay").style.display = "none";
    }
</script>
<script type="64c389be0a9e467db0b8a158-text/javascript">
    var $filtersSelect = $('.home_filter');
    // init Isotope
    var $grid_home = $('.grid_home').isotope({
        itemSelector: '.element-item',
        layoutMode: 'fitRows',
        filter: $filtersSelect.val(),
    });
    // bind filter on select change
    $filtersSelect.on( 'change', function() {
        // get filter value from option value
        $grid_home.isotope({ filter: this.value });
    });

</script>
<script type="64c389be0a9e467db0b8a158-text/javascript">
//         $(document).ready(function(){
//         $("#session_modal").modal('show');
//         setTimeout(function() {
//         $('#session_modal').modal('hide');
//     }, 10000);
//     });
</script>
<script type="64c389be0a9e467db0b8a158-text/javascript">
    $('#regBtn').on('click',function(){
        var full_name = $('#fullName').val();
        var email = $('#emailAddress').val();
        var phone_number = $('#phoneNumber').val();
        var selectCourse = $('#selectCourse').val();
        console.log(full_name,email, phone_number,selectCourse);
        if(full_name == '' || email == '' || phone_number == '' || selectCourse == ''){
            // alert('Please fill up all the fields!');
            $('#exampleModal1').modal('show');
        }else{
            $('#exampleModal').modal('show');
        }
    });
    $('#regBtn2').on('click',function(){
        var full_name = $('#fullName').val();
        var email = $('#emailAddress').val();
        var phone_number = $('#phoneNumber').val();
        var selectCourse = $('#selectCourse').val();
        console.log(full_name,email, phone_number,selectCourse);
        if(full_name == '' || email == '' || phone_number == '' || selectCourse == ''){
            // alert('Please fill up all the fields!');
            // $('#formText').html('*Please fill up all the fields!');

            $('#exampleModal1').modal('show');
        }else{
            $('#regBtn2').removeAttr("type").attr("type", "submit");
        }
    });
</script>
<script type="64c389be0a9e467db0b8a158-text/javascript">
    $(document).ready(function()
    {
        jQuery.validator.addMethod(
            "regex",
            function(value, element, regexp) {
                if (regexp.constructor != RegExp)
                    regexp = new RegExp(regexp);
                else if (regexp.global)
                    regexp.lastIndex = 0;
                return this.optional(element) || regexp.test(value);
            },"Invalid Format"
        );

        $("#basic-form").validate({
                rules: {
                        full_name:
                            {
                                required: true,
                                regex: '[a-zA-Z]+'
                            },
                        email_address:
                            {
                                required: true,
                                regex: '^([a-zA-Z0-9_\\-\\.]+)@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.)|(([a-zA-Z0-9\\-]+\\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\\]?)$'
                            },
                        phone_number:
                            {
                                required: true,
                                regex: '\\+?(88)?0?1[3456789][0-9]{8}\\b'
                            },
                    },
                // messages:
                //     {
                //         full_name:
                //             {
                //                 required: "Please enter your full name"
                //             },
                //         email_address:
                //             {
                //                 required: "Please enter your email address."
                //             },
                //         phone_number:
                //             {
                //                 required: "Please enter your phone number."
                //             },
                //     }
            });
    });
    $(document).ready(function()
    {
        jQuery.validator.addMethod(
            "regex",
            function(value, element, regexp) {
                if (regexp.constructor != RegExp)
                    regexp = new RegExp(regexp);
                else if (regexp.global)
                    regexp.lastIndex = 0;
                return this.optional(element) || regexp.test(value);
            },"Invalid Format"
        );

        $("#basic-form3").validate({
            rules: {
                full_name:
                    {
                        required: true,
                        regex: '[a-zA-Z]+'
                    },
                email_address:
                    {
                        required: true,
                        regex: '^([a-zA-Z0-9_\\-\\.]+)@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.)|(([a-zA-Z0-9\\-]+\\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\\]?)$'
                    },
                phone_number:
                    {
                        required: true,
                        regex: '\\+?(88)?0?1[3456789][0-9]{8}\\b'
                    },
            },
            // messages:
            //     {
            //         full_name:
            //             {
            //                 required: "Please enter your full name"
            //             },
            //         email_address:
            //             {
            //                 required: "Please enter your email address."
            //             },
            //         phone_number:
            //             {
            //                 required: "Please enter your phone number."
            //             },
            //     }
        });

        $('#basic-form3 input').on('keyup blur', function () {
            if ($('#basic-form3').valid()) {
                $('button.apply-btn1').prop('disabled', false);
            } else {
                $('button.apply-btn1').prop('disabled', 'disabled');
            }
        });
    });
    $(document).ready(function()
    {
        jQuery.validator.addMethod(
            "regex",
            function(value, element, regexp) {
                if (regexp.constructor != RegExp)
                    regexp = new RegExp(regexp);
                else if (regexp.global)
                    regexp.lastIndex = 0;
                return this.optional(element) || regexp.test(value);
            },"Invalid Format"
        );

        $("#basic-form4").validate({
            rules: {
                full_name:
                    {
                        required: true,
                        regex: '[a-zA-Z]+'
                    },
                email_address:
                    {
                        required: true,
                        regex: '^([a-zA-Z0-9_\\-\\.]+)@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.)|(([a-zA-Z0-9\\-]+\\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\\]?)$'
                    },
                phone_number:
                    {
                        required: true,
                        regex: '\\+?(88)?0?1[3456789][0-9]{8}\\b'
                    },
            },
            // messages:
            //     {
            //         full_name:
            //             {
            //                 required: "Please enter your full name"
            //             },
            //         email_address:
            //             {
            //                 required: "Please enter your email address."
            //             },
            //         phone_number:
            //             {
            //                 required: "Please enter your phone number."
            //             },
            //     }
        });
    });
    $(document).ready(function()
    {
        jQuery.validator.addMethod(
            "regex",
            function(value, element, regexp) {
                if (regexp.constructor != RegExp)
                    regexp = new RegExp(regexp);
                else if (regexp.global)
                    regexp.lastIndex = 0;
                return this.optional(element) || regexp.test(value);
            },"Invalid Format"
        );

        $("#basic-form5").validate({
            rules: {
                full_name:
                    {
                        required: true,
                        regex: '[a-zA-Z]+'
                    },
                email_address:
                    {
                        required: true,
                        regex: '^([a-zA-Z0-9_\\-\\.]+)@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.)|(([a-zA-Z0-9\\-]+\\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\\]?)$'
                    },
                phone_number:
                    {
                        required: true,
                        regex: '\\+?(88)?0?1[3456789][0-9]{8}\\b'
                    },
            },
            // messages:
            //     {
            //         full_name:
            //             {
            //                 required: "Please enter your full name"
            //             },
            //         email_address:
            //             {
            //                 required: "Please enter your email address."
            //             },
            //         phone_number:
            //             {
            //                 required: "Please enter your phone number."
            //             },
            //     }
        });
    });

    $(document).ready(function()
    {
        jQuery.validator.addMethod(
            "regex",
            function(value, element, regexp) {
                if (regexp.constructor != RegExp)
                    regexp = new RegExp(regexp);
                else if (regexp.global)
                    regexp.lastIndex = 0;
                return this.optional(element) || regexp.test(value);
            },"Invalid Format"
        );

        $("#basic-form6").validate({
            rules: {
                first_name:
                    {
                        required: true,
                        regex: '[a-zA-Z]+'
                    },
                last_name:
                    {
                        required: true,
                        regex: '[a-zA-Z]+'
                    },
                email:
                    {
                        required: true,
                        regex: '^([a-zA-Z0-9_\\-\\.]+)@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.)|(([a-zA-Z0-9\\-]+\\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\\]?)$'
                    },
                phone:
                    {
                        required: true,
                        regex: '\\+?(88)?0?1[3456789][0-9]{8}\\b'
                    },
                message:
                    {
                        required: true,
                    },
            },
            messages:
                {
                    first_name:
                        {
                            required: "Please enter your first name"
                        },
                    last_name:
                        {
                            required: "Please enter your last name"
                        },
                    email:
                        {
                            required: "Please enter your email address."
                        },
                    phone:
                        {
                            required: "Please enter your phone number."
                        },
                    message:
                        {
                            required: "Please enter your message."
                        },
                }
        });
    });
</script>
<script type="64c389be0a9e467db0b8a158-text/javascript">
    $(document).ready(function()
    {
        jQuery.validator.addMethod(
            "regex",
            function(value, element, regexp) {
                if (regexp.constructor != RegExp)
                    regexp = new RegExp(regexp);
                else if (regexp.global)
                    regexp.lastIndex = 0;
                return this.optional(element) || regexp.test(value);
            },"Invalid Format"
        );

        $("#basic-form1").validate({
            rules: {
                full_name:
                    {
                        required: true,
                        regex: '[a-zA-Z]+'
                    },
                email_address:
                    {
                        required: true,
                        regex: '^([a-zA-Z0-9_\\-\\.]+)@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.)|(([a-zA-Z0-9\\-]+\\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\\]?)$'
                    },
                phone_number:
                    {
                        required: true,
                        regex: '\\+?(88)?0?1[3456789][0-9]{8}\\b'
                    },
                password:
                    {
                        required: true,
                    },
            },
            messages:
                {
                    full_name:
                        {
                            required: "Please enter your full name"
                        },
                    email_address:
                        {
                            required: "Please enter your email address."
                        },
                    phone_number:
                        {
                            required: "Please enter your phone number."
                        },
                    password:
                        {
                            required: "Please enter your password."
                        },
                }
        });
    });
</script>
<script type="64c389be0a9e467db0b8a158-text/javascript">
    $(document).ready(function()
    {
        jQuery.validator.addMethod(
            "regex",
            function(value, element, regexp) {
                if (regexp.constructor != RegExp)
                    regexp = new RegExp(regexp);
                else if (regexp.global)
                    regexp.lastIndex = 0;
                return this.optional(element) || regexp.test(value);
            },"Invalid Format"
        );

        $("#basic-form2").validate({
            rules: {
                subscribe:
                    {
                        required: true,
                        regex: '^([a-zA-Z0-9_\\-\\.]+)@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.)|(([a-zA-Z0-9\\-]+\\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\\]?)$'
                    },
            },
            messages:
                {
                    subscribe:
                        {
                            required: "Please enter your email address."
                        },
                }
        });
    });
</script>
<script type="64c389be0a9e467db0b8a158-text/javascript">
    // makes sure the whole site is loaded
	jQuery(window).load(function() {
        // will first fade out the loading animation
    jQuery("").fadeOut();
        // will fade out the whole DIV that covers the website.
    jQuery("#loader").delay(1000).fadeOut("slow");
})

</script>
<script type="64c389be0a9e467db0b8a158-text/javascript">
    // api call for district,sub-district
    // load the district from Ajax call for Present Address
    $('#pre_division').change(function () {
        //var a = $('#division option:selected').text();
        var division_id = $('#pre_division').val();
        $('#pre_district').empty();
        $.ajax({
            type: "GET",
            url: "https://pencilbox.edu.bd/districts",
            data: {division_id: division_id},
            dataType: "json",
            success: function (data) {
                $('#pre_district').append('<option value="0" selected="selected">Select District</option>');
                for (var i = 0; i < data.length; i++) {
                    if(division_id == data[i].division_id){
                        $("#pre_district").append('<option value="' + data[i].id + '">' + data[i].name + '</option>');
                    }
                }
            }
        });
    });
    // load the Sub district from Ajax call for Present Address
    $('#pre_district').change(function () {
        //var c = $('#district option:selected').text();
        var district_id = $('#pre_district').val();
        $('#pre_sub_district').empty();
        $.ajax({
            type: "GET",
            url: "https://pencilbox.edu.bd/sub-districts",
            data: {district_id: district_id},
            dataType: "json",
            success: function (data) {
                $('#pre_sub_district').append('<option value="0" selected="selected">Select Sub District</option>');
                for (var i = 0; i < data.length; i++) {
                    if(district_id == data[i].district_id){
                        $("#pre_sub_district").append('<option value="' + data[i].id + '">' + data[i].name + '</option>');
                    }
                }
            }
        });
    });
</script>
<script type="64c389be0a9e467db0b8a158-text/javascript">
    $(document).ready(function ($) {
        show_course_fee('no');
    });

    function show_course_fee(is_fee) {
        if (is_fee === 'yes') {
            $('#course_fee').toggle();
        } else {
            $('#course_fee').hide();
        }
    }
</script>

<script type="64c389be0a9e467db0b8a158-text/javascript">
    //Get the button
    var mybutton = document.getElementById("return_top");

    // When the user scrolls down 20px from the top of the document, show the button
    window.onscroll = function() {scrollFunction()};

    function scrollFunction() {
        if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
            mybutton.style.display = "block";
        } else {
            mybutton.style.display = "none";
        }
    }

    // When the user clicks on the button, scroll to the top of the document
    function topFunction() {
        document.body.scrollTop = 0;
        document.documentElement.scrollTop = 0;
    }
</script>
<script type="64c389be0a9e467db0b8a158-text/javascript">
    function removePosition() {
        var element = document.getElementById("zIndexId");
        element.classList.remove("positionClass");
    }
</script>
<script type="64c389be0a9e467db0b8a158-application/javascript">
    if ("") {
        swal({
            title: "Warning!",
            text: "",
            icon: "warning"
        });
        
    } else if("") {
        swal({
            title: "Info!",
            text: "",
            icon: "info"
        });
        
    }else if("") {
        swal({
            title: "Congrats!",
            text: "",
            icon: "success"
        });
        
    }else if("") {
        swal({
            title: "Error!",
            text: "",
            icon: "error"
        });
        
    } else
    if("") {
        $('#modalCheckMailForm').modal('show');
        $('#modalCheckMailForm, .modal-backdrop').removeClass('in');
        $('#modalCheckMailForm, .modal-backdrop').addClass('show');
    } else if("") {
        $('#modalCongratulationWOLoginForm').modal('show');
        $('#modalCongratulationWOLoginForm, .modal-backdrop').removeClass('in');
        $('#modalCongratulationWOLoginForm, .modal-backdrop').addClass('show');
    } else if("") {
        // $('#modalCongratulationWLoginForm').modal('show');
        // $('#modalCongratulationWLoginForm, .modal-backdrop').removeClass('in');
        // $('#modalCongratulationWLoginForm, .modal-backdrop').addClass('show');
        $('#modalCongratulationWLoginFormCoursePage').modal('show');
        $('#modalCongratulationWLoginFormCoursePage, .modal-backdrop').removeClass('in');
        $('#modalCongratulationWLoginFormCoursePage, .modal-backdrop').addClass('show');
    }
    // else {
    //     $('#modalCongratulationWLoginFormCoursePage').modal('show');
    //     $('#modalCongratulationWLoginFormCoursePage, .modal-backdrop').removeClass('in');
    //     $('#modalCongratulationWLoginFormCoursePage, .modal-backdrop').addClass('show');
    // }
</script>
<script src="rocket-loader.min.js" data-cf-settings="64c389be0a9e467db0b8a158-|49" defer=""></script>

</body></html>