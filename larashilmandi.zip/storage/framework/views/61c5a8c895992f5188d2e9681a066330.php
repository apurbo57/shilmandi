<?php if(Session('success')): ?>
    <div class="alert alert-success fade in">
        <a href="#" class="close" data-dismiss="alert">×</a>
        <strong><?php echo e(Session('success')); ?></strong>
    </div>
<?php endif; ?>

<?php if(Session('danger')): ?>
    <div class="alert alert-danger fade in">
        <a href="#" class="close" data-dismiss="alert">×</a>
        <strong><?php echo e(Session('danger')); ?></strong>
    </div>
<?php endif; ?>

<?php if($errors->any()): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="alert alert-danger fade in">
        <a href="#" class="close" data-dismiss="alert">×</a>
        <strong><?php echo e($error); ?></strong>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\larashilmandi\resources\views/includes/message.blade.php ENDPATH**/ ?>