

<?php $__env->startSection('admin_content'); ?>
    <ul class="breadcrumb">
        <li>
            <i class="icon-home"></i>
            <a href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
            <i class="icon-angle-right"></i> 
        </li>
        <li>
            <i class="icon-edit"></i>
            <a href="#">Add Product</a>
        </li>
    </ul>
<div class="row-fluid sortable">
  <?php echo $__env->make('includes.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="box span12">
        <div class="box-header" data-original-title>
            <h2><i class="halflings-icon edit"></i><span class="break"></span>Add Product</h2>
            <div class="box-icon">
                <a href="#" class="btn-setting"><i class="halflings-icon wrench"></i></a>
                <a href="#" class="btn-minimize"><i class="halflings-icon chevron-up"></i></a>
                <a href="#" class="btn-close"><i class="halflings-icon remove"></i></a>
            </div>
        </div>
        <div class="box-content">
        <form class="form-horizontal" action="<?php echo e(route('admin.save-course')); ?>" method="post" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>;
              <fieldset>
                <div class="control-group">
                  <label class="control-label" for="typeahead">Course Name</label>
                  <div class="controls">
                    <input type="text" class="span6 typeahead" name="course_name" value="<?php echo e(Request::old('p_name')); ?>" id="typeahead" >
                  </div>
                </div>
                <div class="control-group hidden-phone">
                  <label class="control-label" for="textarea2">Course Description</label>
                  <div class="controls">
                    <textarea class="cleditor" name="course_description" id="textarea2" rows="2"></textarea>
                  </div>
                </div>
                <div class="control-group">
                  <label class="control-label" for="typeahead">Course Image</label>
                  <div class="controls">
                    <input type="file" class="span6 typeahead" name="course_image" id="typeahead" >
                  </div>
                </div>
                <div class="control-group">
                  <label class="control-label" for="typeahead">Course Price</label>
                  <div class="controls">
                    <input type="number" class="span6 typeahead" name="course_price" placeholder="00.00" id="typeahead" >
                  </div>
                </div>
                <div class="control-group">
                  <label class="control-label" for="typeahead">Registration Deadline</label>
                  <div class="controls">
                    <input type="date" class="span6 typeahead" name="sp_start" id="typeahead" >
                  </div>
                </div>
                <div class="control-group">
                  <label class="control-label" for="typeahead">Assessment Date</label>
                  <div class="controls">
                    <input type="date" class="span6 typeahead" name="sp_end" id="typeahead" >
                  </div>
                </div>
                <div class="control-group">
                  <label class="control-label" for="typeahead">Batch No</label>
                  <div class="controls">
                    <input type="number" class="span6 typeahead" name="batch_no" placeholder="00" id="typeahead" >
                  </div>
                </div>
                <div class="control-group">
                  <label class="control-label" for="typeahead">No. of Classes/ Sessions</label>
                  <div class="controls">
                    <input type="number" class="span6 typeahead" name="classes" id="typeahead" >
                  </div>
                </div>
                <div class="control-group">
                  <label class="control-label">Course Type</label>
                  <div class="controls">
                    <label class="radio">
                    <input type="radio" name="optionsRadios" id="optionsRadios1" value="option1" checked="">
                    Regular
                    </label>
                    <div style="clear:both"></div>
                    <label class="radio">
                    <input type="radio" name="optionsRadios" id="optionsRadios2" value="option2">
                    RPL
                    </label>
                  </div>
                  </div>
                <div class="form-actions">
                  <button type="submit" class="btn btn-primary">Add Product</button>
                  <a href="<?php echo e(url()->previous()); ?>" class="btn">Cancle</a>
                </div>
              </fieldset>
            </form>   

        </div>
    </div><!--/span-->

</div><!--/row-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larashilmandi\resources\views/admin/product_add.blade.php ENDPATH**/ ?>