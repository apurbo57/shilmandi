
<?php $__env->startSection('content'); ?>


<div class="training-details-area">
        <div class="container">
        <div class="row">
        <div class="col-xl-12">
        <div class="traning-details-header">
        <style>
                                    .traning-details-header .h3{
                                        color: #fff;
                                        font-size: 28px;
                                    }
                                    @media (min-width: 768px) and (max-width: 991px){
                                        .traning-details-header .h3 {
                                            font-size: 20px;
                                        }
                                    }
                                    @media (max-width: 767px){
                                        .traning-details-header .h3 {
                                            font-size: 18px;
                                        }
                                    }
                                </style>
        
        <h1 class="h2 font-weight-bold text-center"><?php echo e($course->course_name); ?></h1>
        <div class="row">
        <div class="col-sm-6">
        <ul>
            <li>
            <i class="far fa-clock"></i><span>Registration Deadline :</span> <?php echo e($course->reg_date); ?>

            </li>
        <li>
        <i class="fa fa-calendar"></i><span>Assessment Date :</span> <?php echo e($course->ass_date); ?>

        </li>
        </ul>
        </div>
        <div class="col-sm-6">
        <ul>
        <li><i class="fa fa-users" aria-hidden="true" style="margin-right: 13px;"></i></i><span>Batch No : <?php echo e($course->batch_no); ?></span></li>
        <li>
                <i class="fas fa-stopwatch"></i><span>No. of Classes/ Sessions :</span> <?php echo e($course->classes); ?>

                </li>
        </ul>
        </div>
        </div>
        </div>
        </div>
        </div>
        </div>
        </div>
        
        
        <div class="training-details-content-area">
        <div class="container">
        <div class="row">
        <div class="col-xl-8 col-lg-8 col-md-12">
        <div class="traning-content">
        <img src="<?php echo e(asset('uploads/course/'. $course->image)); ?>" alt="Computer Operation- Level 03 (NSDA)" loading="lazy">
        <a type="button" class="btn mobile-fixed-btn small-text" href="#mobile-fixed">apply</a>
        <h4>Introduction</h4>
        <div><?php echo html_entity_decode($course->course_description) ?></div>


        
        
        
        </div>
        <style>
        .sm-text {
            font-size: 10px;
            letter-spacing: 1px;
        }
        .sm-text-1 {
            font-size: 14px;
        }
        .review_title{
            font-weight: 600;
        }
        .avarage-review-tab {
            background-color: #FBB216;
            border-radius: 5px;
            padding: 5px 3px 5px 3px;
        }
        .avarage-review-tab p{
            margin-left: 0;
        }
        .avarage-review-tab h4{
            font-weight: 600;
        }
        .all-reviews-tab{
            background-color: #132B48;
            border-radius: 5px;
            padding: 5px 3px 5px 3px;
        }
        .all-reviews-tab p{
            color: #fff;
            margin-left: 0;
        }
        .all-reviews-tab h4{
            color: #fff;
            font-weight: 600;
        }
        .profile-pic{
            border: 1px solid #132B48;
            display: flex;
            align-items: center;
            padding: 8px;
        }
        .profile-pic img {
            border-radius: 50%;
        }
        .avarage-review-tab{
                margin-left: 0 !important;
        }
        .rate {
            display: flex;
            flex-direction: row-reverse;
            justify-content: flex-end;
            align-items: center;
            height: 46px;
        }
        .rate input.review_rating{
            display: flex;
            appearance: none;
            font-size: 36px;
            color: #ccc;
            top: unset;
            left: unset;
        }
        .rate>input.review_rating:before{
            content: '★ ';
        }
        .rate>input.review_rating:checked,
        .rate>input.review_rating:checked~input.review_rating{
            color: #ffc700;
            transition: all .2s ease-in-out;
        }
        .rate>input.review_rating:checked~input.review_rating,
        .rate>input.review_rating:hover~input.review_rating:checked~input.review_rating {
            color: #ffc700;
            transition: all .2s ease-in-out;
        }
        @media (max-width:768px){
            .all-reviews-tab{
                margin-left:0 !important;
            }
        }
        @media (max-width:480px){
            .review_users{
                padding: 10px !important;
            }
            .review_info{
                padding: 10px !important;
            }
        }
        </style>
        <div class="container-fluid px-0 py-5 mx-auto">
        <div class="row justify-content-center mx-0 mx-md-auto">
        <div class="col-lg-12 col-md-12 px-1 px-sm-2 border-1">
        
        </div>
        </div>
        </div>
        </div>
        <div class="col-xl-4 col-lg-4 col-md-12" id="mobile-fixed">
        <div class="sidebar-details"></div>
        <div class="pricing-details form-sticky" style="background: none" id="myHeader">
        
        <div style="background: #E6E6E6">
        <div class="price">
        <h6 class>
        Certification Fees :
        <span>
        TK. <?php echo e($course->course_price); ?>

        </span>
        (Non-Refundable)
        </h6>
        <div class="pricing-contact" style="background: #E6E6E6;padding-top:10px">
        <div class="modal fade" id="modalCongratulationWOLoginForm" tabindex="1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" data-backdrop="static" data-keyboard="false">
        
        
        
         
        </div>
        <a href="<?php echo e(route('apply_course',$course->id)); ?>" style="color: white; text-decoration: none;">
            <button type="button" class="btn btn-primary apply-btn">
            Apply Now
            </button>
        </a>
        
        <h6>Contact info</h6>
        
        
        <div class="single-widget padding-extra">
        <p><i class="fas fa-mobile-alt"></i><span>+880 1982-927790</span></p>
        <p><i class="fas fa-phone"></i>+880 1721-297490</p>
        <p><i class="fas fa-envelope"></i>sydtcnrsingdi@gmail.com</p>
        </div>
        </div>
        </div>
        </div>

        </div>
        </div>
        </div>
        </div>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.components.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larashilmandi\resources\views/frontend/single-course.blade.php ENDPATH**/ ?>