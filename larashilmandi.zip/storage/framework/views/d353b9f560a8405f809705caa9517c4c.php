<h1>Hello</h1>
<h4><?php echo e($data); ?></h4>
<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias necessitatibus quisquam deserunt animi repellat temporibus pariatur nulla vitae ducimus, quidem inventore similique impedit at nesciunt ratione culpa modi eos earum!</p>
<?php /**PATH C:\xampp\htdocs\larashilmandi\resources\views/frontend/components/apply-form.blade.php ENDPATH**/ ?>