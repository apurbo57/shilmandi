
<?php $__env->startSection('admin_content'); ?>
<ul class="breadcrumb">
    <li>
        <i class="icon-home"></i>
        <a href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
        <i class="icon-angle-right"></i>
    </li>
    <li><a href="#">All Notice</a></li>
</ul>
<?php echo $__env->make('includes.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="row-fluid sortable">		
    <div class="box span12">
        <div class="box-header" data-original-title>
            <h2><i class="halflings-icon user"></i><span class="break"></span>All Notice List</h2>
            <div class="box-icon">
                <a href="#" class="btn-setting"><i class="halflings-icon wrench"></i></a>
                <a href="#" class="btn-minimize"><i class="halflings-icon chevron-up"></i></a>
                <a href="#" class="btn-close"><i class="halflings-icon remove"></i></a>
            </div>
        </div>
        <div class="box-content">
            <table class="table table-striped table-bordered bootstrap-datatable datatable">
              <thead>
                  <tr>
                      <th>Serial No.</th>
                      <th>Date</th>
                      <th>Title</th>
                      <th>Notice</th>
                      <th>Actions</th>
                  </tr>
              </thead>   
              <tbody>
                <?php ($i=1); ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                <tr>
                    <td><?php echo e($i); ?></td>
                    <td class="center"><?php echo e($datas->created_at->format('d-m-Y')); ?></td>
                    <td class="center"><?php echo e($datas->title); ?></td>
                    <td class="center"><?php echo e(substr($datas->notice, 0,  150)); ?></td>
                    <td class="center">
                        <form action="<?php echo e(route('admin.delete-notice',$datas->id)); ?>" method="post">
                            <?php echo method_field('DELETE'); ?>
                            <?php echo csrf_field(); ?>
                            <a class="btn btn-info" href="<?php echo e(route('admin.edit-notice',$datas->id)); ?>"><i class="halflings-icon white edit"></i></a>
                            <a class="btn btn-danger" onclick="event.preventDefault(); this.closest('form').submit()" href="<?php echo e(route('admin.delete-notice',$datas->id)); ?>">
                                <i class="halflings-icon white trash"></i> 
                            </a>
                        </form>
                    </td>
                </tr>
                <?php ($i++); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
          </table>            
        </div>
    </div><!--/span-->

</div><!--/row-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larashilmandi\resources\views/admin/notice_all.blade.php ENDPATH**/ ?>