
<?php $__env->startSection('content'); ?>


<div class="blog-list-area section-padding">
    <div class="container">
      <div class="row">
        <div class="col-xl-8 col-lg-8 col-md-12">
          <div class="about-content single-sidebar">
            <h4><?php echo e($notice->title); ?></h4>
            <p><?php echo html_entity_decode($notice->notice) ?></p>
          </div>
        </div>
            <div class="col-xl-4 col-lg-4 col-md-12">
              <div class="blog-right ">
              <div class="widget widget-thumb single-sidebar blog-single">
              <h3>Latest Notice</h3>
              <ul class="thumb_post">

                    <?php $__currentLoopData = $notices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                     
                    <li>
                    <img src="<?php echo e(asset('images/6533c7d6604ee-2023-Oct-Sat-12-45-10.Computer%20Operation.webp')); ?>" alt="">
                    <h4><a href="<?php echo e(route('single-notice',$item->id)); ?>"><?php echo e($item->title); ?></a></h4>
                    <p class="post-date"><?php echo e($item->created_at->format('d-m-Y')); ?></p>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
              <a href="<?php echo e(route('notice')); ?>" class="btn-primary p-1">See More</a>
              </div>
              </div>
          </div>
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.components.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larashilmandi\resources\views/frontend/single-notice.blade.php ENDPATH**/ ?>