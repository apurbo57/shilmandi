

<?php $__env->startSection('admin_content'); ?>
    <ul class="breadcrumb">
        <li>
            <i class="icon-home"></i>
            <a href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
            <i class="icon-angle-right"></i> 
        </li>
        <li>
            <i class="icon-edit"></i>
            <a href="#">Edit Count Down</a>
        </li>
    </ul>
<div class="row-fluid sortable">
  <?php echo $__env->make('includes.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="box span12">
        <div class="box-header" data-original-title>
            <h2><i class="halflings-icon edit"></i><span class="break"></span>Edit Count Down</h2>
            <div class="box-icon">
                <a href="#" class="btn-setting"><i class="halflings-icon wrench"></i></a>
                <a href="#" class="btn-minimize"><i class="halflings-icon chevron-up"></i></a>
                <a href="#" class="btn-close"><i class="halflings-icon remove"></i></a>
            </div>
        </div>
        <div class="box-content">
        <form class="form-horizontal" action="<?php echo e(route('admin.update-countdown',$data->id)); ?>" method="post">
          <?php echo csrf_field(); ?>
          <?php echo method_field('put'); ?>
              <fieldset>
                
                <div class="control-group">
                  <label class="control-label" for="typeahead">Batches</label>
                  <div class="controls">
                    <input type="number" class="span6 typeahead" name="batches" value="<?php echo e($data->batches); ?>" id="typeahead" >
                  </div>
                </div>
                
                <div class="control-group">
                  <label class="control-label" for="typeahead">Student</label>
                  <div class="controls">
                    <input type="number" class="span6 typeahead" name="student" value="<?php echo e($data->student); ?>" id="typeahead" >
                  </div>
                </div>
                
                <div class="control-group">
                  <label class="control-label" for="typeahead">Job Placement</label>
                  <div class="controls">
                    <input type="number" class="span6 typeahead" name="jobplacement" value="<?php echo e($data->jobplacement); ?>" id="typeahead" >
                  </div>
                </div>
                
                <div class="control-group">
                  <label class="control-label" for="typeahead">Skilled Trainer</label>
                  <div class="controls">
                    <input type="number" class="span6 typeahead" name="trainer" value="<?php echo e($data->trainer); ?>" id="typeahead" >
                  </div>
                </div>
                <div class="form-actions">
                  <button type="submit" class="btn btn-primary">Update Count Down</button>
                  <a href="<?php echo e(url()->previous()); ?>" class="btn">Cancle</a>
                </div>
              </fieldset>
            </form>   

        </div>
    </div><!--/span-->

</div><!--/row-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larashilmandi\resources\views/admin/count_down.blade.php ENDPATH**/ ?>